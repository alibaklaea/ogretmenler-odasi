window.CANVA = {
  hazirlik: [
    "Canva Eğitim öğretmenler ve öğrenciler için ücretsizdir: canva.com/education adresinden öğretmen hesabınızı doğrulayın.",
    "Bir sınıf oluşturup öğrencileri davet bağlantısıyla ekleyin; öğrenciler kişisel e-posta ve şifre paylaşmadan sınıfa katılır.",
    "Öğrencilerin yüzünü, adını-soyadını ve okul bilgisini içeren görselleri herkese açık paylaşmayın; ürünleri sınıf içinde ya da TwinSpace'te paylaşın.",
    "Bilgisayar yoksa etkinlik tahtada öğretmen gösterimiyle ve gruplar sırayla gelerek yapılabilir; tablette Canva uygulaması da kullanılabilir."
  ],
  etkinlikler: [
    {
      ay: 8,
      ad: "Dijital Kimlik Kartım",
      beceri: "Temel tasarım: şablon, metin, öğe, renk",
      gun: "İlköğretim Haftası",
      sure: "2 × 40'",
      amac: "Canva arayüzünü tanır; şablonu kendi bilgileriyle kişiselleştirerek dijital bir tanıtım kartı tasarlar.",
      urun: "Kişisel bilgi içermeyen ‘Ben kimim?’ dijital kimlik kartı (takma ad, ilgi alanları, en sevdiğim oyun, hayalim)",
      araclar: ["Tasarım oluştur (Create a design)", "Şablonlar (Templates)", "Metin (Text)", "Öğeler (Elements)", "Renk paleti", "İndir (Download) → PNG"],
      adimlar: [
        ["Canva'yı aç", "canva.com'a gir, öğretmeninin sınıf bağlantısıyla oturum aç."],
        ["Tasarım türünü seç", "Ana sayfada arama kutusuna “kart” ya da “poster” yaz; dikey bir boyut seç."],
        ["Şablon seç", "Soldaki Şablonlar (Templates) bölümünden sade bir şablon seç; tıklayınca sayfaya gelir."],
        ["Metinleri değiştir", "Yazıların üstüne çift tıkla: takma adını, ilgi alanlarını ve hayalini yaz. Gerçek adını ve okulunu yazma."],
        ["Öğe ekle", "Öğeler (Elements) bölümünde “oyun”, “bilim”, “kitap” gibi kelimeler ara; ilgi alanını anlatan 3 öğe ekle."],
        ["Renkleri düzenle", "Bir şekli seç, üst çubuktaki renk kutusuna tıkla; kartın 2-3 ana rengini seç."],
        ["Hizala", "Öğeleri sürükle; mor kılavuz çizgileri ortaya geldiğini gösterir. Taşan yazı kalmasın."],
        ["Kaydet ve indir", "Sağ üstte Paylaş (Share) → İndir (Download) → PNG seç ve indir."]
      ],
      kontrol: ["Kişisel bilgi (gerçek ad, okul, adres) yok", "En az 3 öğe ve 2-3 uyumlu renk kullandım", "Yazılar okunaklı, taşma yok", "Kartım beni anlatıyor"],
      zengin: "Kartı arkadaşının kartıyla karşılaştırıp ortak bir ‘Sınıfımızın İlgi Alanları’ posteri yapar."
    },
    {
      ay: 9,
      ad: "Kayan Yazılı Cumhuriyet Afişi",
      beceri: "Metin animasyonları ve kayan yazı",
      gun: "Cumhuriyet Bayramı · AB Kod Haftası",
      sure: "2 × 40'",
      amac: "Metne giriş animasyonu ve kayan yazı efekti uygular; animasyonun mesajı güçlendirmek için kullanıldığını fark eder.",
      urun: "‘Cumhuriyet ve gelecek’ temalı, kayan yazılı 10-15 saniyelik animasyonlu afiş (MP4 ya da GIF)",
      araclar: ["Metin (Text)", "Canlandır (Animate)", "Metin animasyonları: Daktilo (Typewriter), Yüksel (Rise), Kaydır (Pan) vb.", "Animasyon oluştur (Create an animation)", "Zamanlama (Timing)", "İndir → MP4 / GIF"],
      adimlar: [
        ["Afişi kur", "Tasarım oluştur → “Animasyonlu sosyal medya” ya da “Video” seç. Arka plana bayrak rengi ya da Cumhuriyet temalı bir görsel ekle."],
        ["Başlığı yaz", "Metin (Text) → Başlık ekle; “Cumhuriyet: Geleceğe Bir Adım” gibi kendi sloganını yaz."],
        ["Başlığa giriş animasyonu ver", "Başlığı seç → üst çubukta Canlandır (Animate) → metin animasyonlarından birini seç (ör. Daktilo / Typewriter)."],
        ["Kayan yazı satırını ekle", "Altta tek satır bir metin kutusu oluştur: “29 Ekim 1923 — Cumhuriyet'in ilanı …” gibi uzun bir cümle."],
        ["Kayan yazı efekti ver", "Satırı seç → Canlandır → Animasyon oluştur (Create an animation) → metni tutup sayfanın sağından soluna doğru sürükle; hareket yolu çizilir."],
        ["Hızı ayarla", "Hareket yolunun ayarlarından hızı yavaşlat; yazının rahat okunabildiğini kontrol et."],
        ["Sayfa süresini ayarla", "Altta sayfanın süresine (ör. 5,0 sn) tıkla, 12-15 saniye yap."],
        ["Önizle ve indir", "Oynat (▶) ile izle; Paylaş → İndir → MP4 Video (ya da GIF) seç."]
      ],
      kontrol: ["Başlıkta bir giriş animasyonu var", "Kayan yazı soldan sağa ya da sağdan sola okunur hızda geçiyor", "Animasyonlar mesajı dağıtmıyor (en fazla 2-3 farklı efekt)", "Tarih ve bilgiler doğru"],
      zengin: "Aynı afişin İngilizce sürümünü yapıp eTwinning ortak okuluna gönderir."
    },
    {
      ay: 10,
      ad: "Atatürk ve Bilim: Animasyonlu Zaman Çizelgesi",
      beceri: "İnfografik ve sıralı animasyon",
      gun: "Atatürk Haftası · Dünya Bilim Günü",
      sure: "2 × 40'",
      amac: "Bilgiyi zaman çizelgesi biçiminde düzenler; öğelerin sırayla belirmesini sağlayarak hikâye anlatır.",
      urun: "Atatürk'ün bilim ve eğitimle ilgili 5 önemli adımını gösteren, öğeleri sırayla beliren infografik",
      araclar: ["Şablonlar → “zaman çizelgesi / timeline”", "Çizgi ve şekiller", "Grupla (Group)", "Canlandır → öğe animasyonları", "Zamanlama (Timing)"],
      adimlar: [
        ["Bilgiyi topla", "Çalışma kâğıdındaki tabloya 5 olayı ve yılını yaz (ör. 1928 Harf Devrimi, 1933 Üniversite Reformu)."],
        ["Şablon seç", "Şablonlarda “zaman çizelgesi” (timeline) ara; yatay bir şablon seç."],
        ["Olayları yerleştir", "Her noktaya yılı ve tek cümlelik açıklamayı yaz; gerekmeyen noktaları sil."],
        ["Simge ekle", "Öğeler'de “kitap”, “okul”, “mikroskop” ara; her olaya bir simge koy."],
        ["Grupla", "Bir olayın yıl + metin + simgesini birlikte seç → sağ tık → Grupla (Group)."],
        ["Sırayla belirt", "Her grubu seç → Canlandır → bir giriş animasyonu ver; Zamanlama (Timing) ile grupların birbiri ardına gelmesini ayarla."],
        ["Başlık ve kaynak", "Üste başlık, en alta “Kaynak:” satırı ekle (yararlandığın kitap/site)."],
        ["Sun", "Sağ üstte Sun (Present) → tam ekranda sınıfa anlat."]
      ],
      kontrol: ["5 olay doğru sırada ve yılları doğru", "Her olayın bir simgesi var", "Öğeler sırayla beliriyor", "Kaynak yazıldı"],
      zengin: "Zaman çizelgesine kendi seçtiği bir Türk bilim insanını ekler."
    },
    {
      ay: 11,
      ad: "Hareket Yolu ile Robotu Hedefe Götür",
      beceri: "Hareket yolu animasyonu ve algoritma",
      gun: "Hour of Code / Hour of AI · Avrupa Robotik Haftası",
      sure: "2 × 40'",
      amac: "Bir algoritmayı (ileri, sağa dön…) Canva'da hareket yolu animasyonuna dönüştürür; kodlama ile animasyon arasındaki ilişkiyi kurar.",
      urun: "Labirentte engellere çarpmadan hedefe giden robot animasyonu",
      araclar: ["Öğeler → ızgara/labirent, robot, bayrak", "Animasyon oluştur (Create an animation): öğeyi sürükleyerek yol çizme", "Kilitle (Lock)", "Sayfa süresi"],
      adimlar: [
        ["Algoritmayı kâğıtta yaz", "Çalışma kâğıdındaki ızgarada robotun yolunu ok kartlarıyla planla: ↑ ↑ → → ↓ …"],
        ["Labirenti kur", "Video ya da sunum tasarımı aç; Öğeler'den ızgara ve kare engeller ekle, başlangıca robot, hedefe bayrak koy."],
        ["Labirenti kilitle", "Izgarayı ve engelleri seç → üstteki kilit simgesi (Lock); yanlışlıkla kaymasınlar."],
        ["Hareket yolu çiz", "Robotu seç → Canlandır → Animasyon oluştur → robotu tutup algoritmandaki yoldan hedefe sürükle."],
        ["Yolu düzelt", "Yol engelin üstünden geçiyorsa geri al (Ctrl+Z) ve yeniden çiz; ‘Yolu düzelt’ (smooth) seçeneğini dene."],
        ["Süreyi ayarla", "Sayfa süresini robotun yolunu bitireceği kadar uzat."],
        ["Arkadaşınla test et", "Animasyonu oynat; arkadaşın algoritmanla animasyonun aynı olup olmadığını kontrol etsin (hata ayıklama)."],
        ["Paylaş", "İndir → MP4 ya da GIF; sınıf panosunda algoritmanın yanına koy."]
      ],
      kontrol: ["Robot hiçbir engelin üstünden geçmiyor", "Animasyon kâğıttaki algoritmayla aynı", "Labirent kilitli, kaymıyor", "Arkadaşım test etti"],
      zengin: "İkinci bir robot ekleyip iki robotun çarpışmadan yer değiştirmesini sağlar."
    },
    {
      ay: 0,
      ad: "1 Dakikalık Bilim Videosu",
      beceri: "Video kurgusu: sahne, kırpma, yazı, müzik",
      gun: "Enerji Tasarrufu Haftası",
      sure: "2 × 40'",
      amac: "Bir konuyu senaryo ve sahne planıyla anlatır; görüntüleri kırpar, yazı ve müzik ekleyerek kısa bir video kurgular.",
      urun: "‘Okulumuzda enerjiyi nasıl tasarruf ederiz?’ konulu, 4-6 sahneli, en fazla 60 saniyelik video",
      araclar: ["Tasarım oluştur → Video", "Yüklemeler (Uploads): kendi fotoğraf/video", "Öğeler → Videolar, Ses (Audio)", "Kırp / Böl (Split)", "Metin animasyonları", "İndir → MP4"],
      adimlar: [
        ["Senaryo yaz", "Çalışma kâğıdındaki sahne planına (storyboard) 4-6 sahneyi çiz ve her sahnenin cümlesini yaz."],
        ["Görüntü topla", "Okulda izinli yerlerde ışık, priz, pencere fotoğrafları çek (öğrenci yüzü olmasın)."],
        ["Video aç", "Tasarım oluştur → Video. Her sahne için bir sayfa ekle (+)."],
        ["Görüntüleri yükle", "Yüklemeler (Uploads) → Dosya yükle; her sayfaya bir görüntü sürükle, sayfayı kaplayacak şekilde büyüt."],
        ["Kırp ve süre ver", "Video klibi seç → makas simgesiyle kırp; her sahnenin süresini 8-12 saniye yap."],
        ["Yazı ekle", "Her sahneye kısa bir alt yazı ekle; Canlandır ile yumuşak bir giriş ver."],
        ["Müzik ekle", "Öğeler → Ses (Audio) bölümünden telifsiz bir müzik seç; sesi videonun altına sürükle, sesi kıs."],
        ["Geçiş ekle", "İki sayfanın arasına gelince çıkan + / geçiş simgesinden sade bir geçiş seç."],
        ["İzle ve indir", "Baştan sona izle, toplam süre 60 saniyeyi geçmesin; Paylaş → İndir → MP4."]
      ],
      kontrol: ["Senaryo ve sahneler uyumlu", "Toplam süre 60 saniyeyi geçmiyor", "Müzik telifsiz ve yazıları bastırmıyor", "Öğrenci yüzü ve kişisel bilgi yok"],
      zengin: "Videoya kendi sesiyle anlatım kaydeder (Kayıt / Record yourself) ve Türkçe-İngilizce alt yazı ekler."
    },
    {
      ay: 1,
      ad: "Güvenli İnternet: Animasyonlu GIF Kartları",
      beceri: "Döngülü GIF, telif ve dijital güvenlik",
      gun: "Güvenli İnternet Günü (9 Şubat)",
      sure: "2 × 40'",
      amac: "Güvenli internet kuralını kısa ve döngülü bir animasyonla anlatır; telifsiz içerik kullanmanın önemini kavrar.",
      urun: "‘Dur – Düşün – Sor’ kurallarını anlatan 3 karelik, döngülü GIF serisi",
      araclar: ["Sosyal medya gönderisi boyutu", "Sayfa animasyonları", "Öğeler: kalkan, kilit, uyarı simgeleri", "Sayfa süresi (kısa)", "İndir → GIF"],
      adimlar: [
        ["Kuralları seç", "Kâğıttaki listeden 3 kural seç ve her biri için 5 kelimeyi geçmeyen bir slogan yaz."],
        ["Tasarımı aç", "Tasarım oluştur → Instagram gönderisi (kare). Üç sayfa oluştur."],
        ["Her kural bir sayfa", "Her sayfaya bir slogan ve uyumlu bir simge (kilit, kalkan, ünlem) koy."],
        ["Telifi kontrol et", "Yalnız Canva'nın içindeki ücretsiz öğeleri ya da kendi çizimini kullan; internetten görsel kopyalama."],
        ["Animasyon ver", "Her sayfada simgeyi seç → Canlandır → ‘Nabız’ / ‘Zıpla’ gibi tekrar eden bir efekt seç."],
        ["Süreyi kısalt", "Her sayfanın süresini 2-3 saniye yap; GIF kısa olunca döngü güzel görünür."],
        ["GIF indir", "Paylaş → İndir → Dosya türü: GIF."],
        ["Sınıfta paylaş", "GIF'leri sınıf panosu ekranında ya da TwinSpace'te ‘Güvenli İnternet’ sayfasında paylaş."]
      ],
      kontrol: ["Her kartta tek, açık bir kural var", "Yalnız telifsiz/Canva içi öğeler kullandım", "Animasyon döngüde rahatsız etmiyor", "Kişisel bilgi yok"],
      zengin: "Yapay zekâyla üretilmiş bir görselin nasıl anlaşılacağına dair dördüncü bir kart tasarlar."
    },
    {
      ay: 2,
      ad: "Sesli Dijital Hikâye Kitabı",
      beceri: "Çok sayfalı kitap, ses kaydı ve sayfa geçişleri",
      gun: "Dünya Su Günü · Kütüphaneler Haftası",
      sure: "2 × 40'",
      amac: "Giriş-gelişme-sonuç yapısında bir hikâyeyi çok sayfalı dijital kitaba dönüştürür; kendi sesiyle anlatır.",
      urun: "‘Bir Su Damlasının Yolculuğu’ konulu, 6 sayfalık, sesli dijital hikâye kitabı",
      araclar: ["Tasarım oluştur → Hikâye kitabı / Sunum", "Karakter ve sahne öğeleri", "Kayıt (Record yourself) ya da ses yükleme", "Sayfa geçişleri", "Sun (Present) / Bağlantıyla paylaş"],
      adimlar: [
        ["Hikâyeyi planla", "Kâğıttaki 6 kutulu planı doldur: kapak, giriş, 3 gelişme, sonuç."],
        ["Kitabı aç", "Tasarım oluştur → “hikâye kitabı” ya da “sunum (16:9)” seç; 6 sayfa ekle."],
        ["Kapağı yap", "Kitabın adını ve ‘Yazan-Çizen: (takma ad)’ satırını yaz."],
        ["Sahneleri kur", "Her sayfaya bir arka plan ve karakter (su damlası) öğesi koy; karakter her sayfada aynı olsun."],
        ["Metni yaz", "Her sayfaya 1-3 cümle yaz; yazı büyük ve okunaklı olsun."],
        ["Sesini kaydet", "Yüklemeler (Uploads) → Kendini kaydet (Record yourself) ile her sayfanın metnini sesli oku (ya da telefonla kaydedip yükle)."],
        ["Geçiş ekle", "Sayfalar arasına sade bir geçiş ekle."],
        ["Paylaş", "Sun (Present) ile sınıfta oku ya da Paylaş → görüntüleme bağlantısını öğretmenine gönder."]
      ],
      kontrol: ["Hikâyenin giriş, gelişme ve sonucu var", "Karakter tüm sayfalarda aynı", "Her sayfanın sesi var ve anlaşılır", "Bilimsel bilgi (su döngüsü) doğru"],
      zengin: "Kitabın sonuna su tasarrufu için okuyucuya 3 soruluk bir quiz sayfası ekler."
    },
    {
      ay: 3,
      ad: "Kare Kare Animasyon: 23 Nisan Uçurtması",
      beceri: "Kare kare (stop-motion tarzı) animasyon",
      gun: "Ulusal Egemenlik ve Çocuk Bayramı",
      sure: "2 × 40'",
      amac: "Çok kısa süreli ardışık sayfalarla kare kare animasyonun nasıl oluştuğunu keşfeder; hareketi küçük adımlara böler.",
      urun: "Gökyüzünde süzülüp ‘23 Nisan Kutlu Olsun’ yazısına dönüşen uçurtmanın 8-12 karelik animasyonu",
      araclar: ["Video tasarımı", "Sayfayı çoğalt (Duplicate page)", "Sayfa süresi: 0,2-0,5 sn", "Öğe döndürme ve taşıma", "İndir → MP4 / GIF"],
      adimlar: [
        ["Hareketi planla", "Kâğıttaki film şeridine uçurtmanın 8 karedeki yerini çiz: her karede biraz daha yukarı ve sağa."],
        ["İlk kareyi kur", "Video tasarımı aç; gökyüzü arka planı ve uçurtma öğesi ekle."],
        ["Sayfayı çoğalt", "Sayfanın üstündeki ‘Sayfayı çoğalt’ (Duplicate) düğmesine bas."],
        ["Küçük adım", "Yeni sayfada uçurtmayı çok az kaydır ve biraz döndür. Sonra yine çoğalt, yine kaydır."],
        ["8-12 kare yap", "Son karelerde uçurtmanın arkasında ‘23 Nisan Kutlu Olsun’ yazısı harf harf belirsin (her karede bir harf daha)."],
        ["Kare süresini ayarla", "Her sayfanın süresine tıkla, 0,3 saniye yap; geçişleri kaldır."],
        ["Oynat ve düzelt", "Oynat; hareket sarsılıyorsa iki kare arasına ara kare ekle."],
        ["İndir", "Paylaş → İndir → MP4 ya da GIF."]
      ],
      kontrol: ["En az 8 kare var", "Kareler arası hareket küçük ve düzenli", "Kare süreleri eşit (0,2-0,5 sn)", "Yazı harf harf beliriyor"],
      zengin: "Kendi çizdiği uçurtmayı fotoğraflayıp yükler ve animasyonu kendi çizimiyle yapar."
    },
    {
      ay: 4,
      ad: "Proje Tanıtım Videosu ve QR Kod",
      beceri: "Tanıtım videosu, QR kod ve yaygınlaştırma",
      gun: "Avrupa Günü (9 Mayıs) · TEKNOFEST/eTwinning yaygınlaştırma",
      sure: "2 × 40'",
      amac: "Yıl içindeki bir projeyi 45 saniyelik tanıtım videosuyla anlatır; videoya QR kodla ulaşılan bir poster hazırlar.",
      urun: "Proje tanıtım videosu + videoya bağlanan QR kodlu A4 poster",
      araclar: ["Video tasarımı", "Yüklemeler: proje fotoğrafları", "Metin animasyonları", "Uygulamalar (Apps) → QR kodu", "Paylaş → görüntüleme bağlantısı"],
      adimlar: [
        ["Mesajı yaz", "Kâğıttaki ‘asansör konuşması’nı doldur: Problem ne? Ne yaptık? Kime faydalı?"],
        ["Videoyu kur", "Video tasarımı aç; 4 sahne: problem, çözüm, nasıl çalışıyor, sonuç."],
        ["Görselleri ekle", "Proje fotoğraflarını ve prototip videosunu Yüklemeler'den sahnelere koy."],
        ["Yazı ve animasyon", "Her sahneye kısa başlık; Canlandır ile giriş efekti."],
        ["Videoyu paylaşılabilir yap", "Paylaş → ‘Görüntüleme bağlantısı’ (view-only link) oluştur ve kopyala (öğretmen onayıyla)."],
        ["Posteri aç", "Yeni bir A4 poster tasarımı aç; proje adı, 3 maddelik özet ve bir fotoğraf koy."],
        ["QR kod ekle", "Uygulamalar (Apps) → “QR kodu” ara → video bağlantısını yapıştır → Kod oluştur; posterin köşesine yerleştir."],
        ["Test et ve as", "QR kodu telefonla okut, video açılıyor mu kontrol et; posteri yazdırıp okul panosuna as."]
      ],
      kontrol: ["Video 45 saniye civarı ve 4 sahneli", "QR kod okutulunca video açılıyor", "Posterde ‘eTwinning projesi’ ya da proje adı açıkça yazıyor", "Öğrenci yüzü/kişisel bilgi yok"],
      zengin: "Videonun İngilizce alt yazılı sürümünü ortak okulla paylaşır (eTwinning 5c yaygınlaştırma)."
    },
    {
      ay: 5,
      ad: "Yıl Sonu Dijital Portfolyo Sitesi",
      beceri: "Web sitesi tasarımı ve yansıtma",
      gun: "Çevre Koruma Haftası · yıl sonu",
      sure: "2 × 40'",
      amac: "Yıl boyunca ürettiklerini seçip düzenleyerek tek sayfalık bir portfolyo sitesi tasarlar; öğrenmesini yansıtır.",
      urun: "‘Bu yıl neler öğrendim?’ tek sayfalık portfolyo sitesi (sınıf içinde paylaşılır)",
      araclar: ["Tasarım oluştur → Web sitesi", "Bölümler ve gezinme menüsü", "Yıl içindeki Canva ürünleri (GIF, video, kitap)", "Bağlantı ekle", "Önizle / Yayınla (öğretmen onayıyla)"],
      adimlar: [
        ["Ürünlerini seç", "Kâğıttaki listeden yıl içinde yaptığın en iyi 4 çalışmayı seç ve her biri için ‘Ne öğrendim?’ cümlesi yaz."],
        ["Site aç", "Tasarım oluştur → “Web sitesi” ara; tek sayfalık sade bir şablon seç."],
        ["Bölümleri kur", "Bölümler: Merhaba (takma ad), Çalışmalarım, Ne öğrendim?, Gelecek yıl hedefim."],
        ["Çalışmaları ekle", "Yıl içindeki tasarımlarını Projeler (Projects) bölümünden sayfaya sürükle; video ve GIF'ler sitede oynar."],
        ["Yansıtma yaz", "Her çalışmanın altına ‘Ne öğrendim?’ cümleni yaz."],
        ["Menüyü kontrol et", "Önizle; üstteki menüden bölümlere gidilebildiğini kontrol et."],
        ["Güvenliği kontrol et", "Gerçek ad, okul, fotoğraf yok mu? Öğretmenine göster."],
        ["Paylaş", "Öğretmen onayıyla Yayınla ya da yalnız sınıf içinde Sun (Present) ile göster."]
      ],
      kontrol: ["4 çalışma ve her birinin ‘Ne öğrendim?’ cümlesi var", "Menü bölümlere götürüyor", "Kişisel bilgi yok", "Gelecek yıl hedefi yazıldı"],
      zengin: "Sitesine bir arkadaşının geri bildirimini ‘Ziyaretçi defteri’ bölümü olarak ekler."
    }
  ]
};
