window.GUNLER = [
  // ---------------- MEB belirli gün ve haftalar ----------------
  {
    id: "ilkogretim",
    tur: "milli",
    ad: "İlköğretim Haftası",
    bas: "2026-09-14",
    bit: "2026-09-18",
    anahtar: "İlköğretim",
    sure: "20 dk",
    amac: "Okulun ve öğrenmenin hayatımızdaki yerini fark etmek.",
    akis: ["“Okul olmasaydı ne öğrenemezdik?” sorusuyla 3 dakikalık beyin fırtınası yapılır.", "Öğrenciler bu yıl BİLSEM'de öğrenmek istediği üç şeyi hedef kartına yazar.", "Kartlar “Merak Duvarı”na asılır; yıl sonunda tekrar okunacaktır."],
    ek: {
      baslik: "BU YIL HEDEF KARTIM",
      yonerge: "Bu yıl öğrenmek, denemek ve başarmak istediklerini yaz. Kartı yıl sonunda tekrar okuyacağız.",
      bloklar: [{ t: "boxes", cols: 3, h: 46, items: ["Öğrenmek istediğim", "Denemek istediğim", "Başarmak istediğim"] }, { t: "lines", label: "Yıl sonunda kendime notum:", n: 2 }]
    }
  },
  {
    id: "ankara",
    tur: "milli",
    ad: "Ankara'nın Başkent Oluşu",
    bas: "2026-10-13",
    bit: "2026-10-13",
    anahtar: "Ankara",
    sure: "25 dk",
    amac: "Ankara'nın başkent seçilmesinin stratejik nedenlerini harita üzerinden çıkarmak.",
    akis: ["Türkiye haritası tahtaya yansıtılır; öğrenciler “Bir ülke başkentini seçerken nelere bakar?” sorusuna ölçüt üretir.", "Gruplar İstanbul, İzmir ve Ankara'yı 1923 koşullarına göre ölçüt tablosunda karşılaştırır.", "Sınıf, Ankara'nın neden seçildiğine dair üç gerekçe yazar."],
    ek: {
      baslik: "BAŞKENT SEÇİM KURULU",
      yonerge: "1923 yılındasın. Üç şehri ölçütlere göre 1-3 arası puanla ve kararını gerekçelendir.",
      bloklar: [{ t: "table", cols: ["Ölçüt", "İstanbul", "İzmir", "Ankara"], rows: [["Güvenlik (cepheye, denize uzaklık)"], ["Ulaşım (demiryolu)"], ["Millî Mücadeleye yakınlık"], ["Ülkenin ortasında olma"], ["TOPLAM"]] }, { t: "lines", label: "Kurulumuzun kararı ve gerekçesi:", n: 3 }]
    }
  },
  {
    id: "cumhuriyet",
    tur: "milli",
    ad: "Cumhuriyet Bayramı",
    bas: "2026-10-29",
    bit: "2026-10-29",
    anahtar: "Cumhuriyet",
    sure: "30 dk",
    amac: "Cumhuriyetin getirdiği değişimleri dün-bugün karşılaştırmasıyla yorumlamak.",
    akis: ["“Cumhuriyet” kelimesinin kökü (cumhur: halk) konuşulur.", "Öğrenciler 1923 öncesi ve sonrasını eğitim, kadın hakları, harf, ölçü birimleri açısından karşılaştırır.", "Her öğrenci “Cumhuriyet bana … hakkını verdi” cümlesiyle kokart ya da bayrak kartı hazırlar."],
    ek: {
      baslik: "CUMHURİYET ÖNCESİ - SONRASI",
      yonerge: "Her alan için Cumhuriyetle gelen değişimi yaz.",
      bloklar: [{ t: "table", cols: ["Alan", "Cumhuriyet öncesi", "Cumhuriyetle birlikte"], rows: [["Yönetim"], ["Eğitim"], ["Kadın hakları"], ["Alfabe"], ["Ölçü birimleri"]] }, { t: "boxes", cols: 1, h: 26, items: ["Cumhuriyet bana … hakkını verdi."] }]
    }
  },
  {
    id: "kizilay",
    tur: "milli",
    ad: "Kızılay Haftası",
    bas: "2026-10-29",
    bit: "2026-11-04",
    anahtar: "Kızılay",
    sure: "25 dk",
    amac: "Yardımlaşmanın ve gönüllülüğün toplumsal önemini fark etmek.",
    akis: ["Kızılay'ın 1868'den bu yana afetlerdeki görevleri kısa sunumla tanıtılır.", "Gruplar “Sınıfımızda bir yardım kampanyası” planlar: neye ihtiyaç var, kime, nasıl ulaşırız?", "Planlar oylanır; seçilen fikir okul yönetimine öneri olarak iletilir."],
    ek: {
      baslik: "GÖNÜLLÜ PLANI",
      yonerge: "Grubunla küçük bir yardımlaşma projesi planla.",
      bloklar: [{ t: "boxes", cols: 2, h: 30, items: ["İhtiyaç nedir?", "Kime ulaşacağız?", "Neler yapacağız?", "Nasıl ölçeceğiz? (başarı)"] }]
    }
  },
  {
    id: "ataturk",
    tur: "milli",
    ad: "Atatürk Haftası",
    bas: "2026-11-10",
    bit: "2026-11-16",
    anahtar: "Atatürk Haftası",
    sure: "30 dk",
    amac: "Atatürk'ün bilime ve eğitime verdiği önemi kendi sözlerinden yorumlamak.",
    akis: ["Saat 09.05'te saygı duruşunun anlamı konuşulur.", "Atatürk'ün bilim ve eğitimle ilgili sözleri kartlara yazılı hâlde dağıtılır; gruplar seçtikleri sözü günümüz örneğiyle açıklar.", "Sınıf “Atatürk bugün BİLSEM'i ziyaret etse hangi projemizi görmek isterdi?” sorusunu yazar."],
    ek: {
      baslik: "ATATÜRK'ÜN İZİNDE • SÖZ YORUMU",
      yonerge: "Seçtiğin sözü yaz, ne anlama geldiğini ve bugün nasıl uygulanabileceğini açıkla.",
      bloklar: [{ t: "boxes", cols: 1, h: 20, items: ["Seçtiğim söz:"] }, { t: "boxes", cols: 2, h: 40, items: ["Bence anlamı", "Bugün bir örneği"] }, { t: "lines", label: "Atatürk BİLSEM'i ziyaret etseydi ona şu projemizi gösterirdim:", n: 2 }]
    }
  },
  {
    id: "bilimgunu",
    tur: "dunya",
    ad: "Barış ve Kalkınma için Dünya Bilim Günü (UNESCO)",
    bas: "2026-11-10",
    bit: "2026-11-10",
    anahtar: "",
    sure: "20 dk",
    islenis: "11 Kasım",
    amac: "Bilimin insanlığın ortak sorunlarını çözmedeki rolünü tartışmak. (10 Kasım'da anma törenine öncelik verilir; etkinlik ertesi gün işlenir.)",
    akis: ["Dünyanın üç büyük sorunu (temiz su, salgın hastalık, iklim) kartlarla gösterilir.", "Gruplar her sorunu çözmeye çalışan bir bilim dalı ve bir bilim insanı eşleştirir.", "“Bilim barışa nasıl hizmet eder?” sorusuna ortak bir sınıf cümlesi yazılır."],
    ek: {
      baslik: "BİLİM DÜNYAYI NASIL İYİLEŞTİRİR?",
      yonerge: "Her sorun için ilgili bilim dalını ve olası bir çözümü yaz.",
      bloklar: [{ t: "table", cols: ["Sorun", "Bilim dalı", "Bilimsel çözüm fikri"], rows: [["Temiz suya ulaşamamak"], ["Salgın hastalıklar"], ["İklim değişikliği"], ["Kendi seçtiğim sorun:"]] }]
    }
  },
  {
    id: "afet",
    tur: "milli",
    ad: "Afet Eğitimi Hazırlık Günü",
    bas: "2026-11-12",
    bit: "2026-11-12",
    anahtar: "Afet",
    sure: "30 dk",
    amac: "Deprem ve afet anında doğru davranışları planlamak.",
    akis: ["“Çök-Kapan-Tutun” hareketi uygulamalı gösterilir.", "Gruplar sınıfın krokisini çizip güvenli alanları ve tahliye yolunu işaretler.", "Öğrenciler ailesiyle dolduracakları afet çantası kontrol listesini alır."],
    ek: {
      baslik: "AFET HAZIRLIK KARTIM",
      yonerge: "Sınıfının krokisini çiz, güvenli yerleri yeşille işaretle. Afet çantası listesini ailenle tamamla.",
      bloklar: [{ t: "boxes", cols: 1, h: 60, items: ["SINIF KROKİSİ (güvenli alan • kapı • toplanma yolu)"] }, { t: "check", items: ["Su (kişi başı 3 gün)", "El feneri ve yedek pil", "Düdük", "İlk yardım malzemesi", "Önemli belgelerin fotokopisi", "Kuru gıda", "Aile iletişim kartı"] }]
    }
  },
  {
    id: "cocukhaklari",
    tur: "dunya",
    ad: "Dünya Çocuk Hakları Günü",
    bas: "2026-11-20",
    bit: "2026-11-20",
    anahtar: "Çocuk Hakları",
    sure: "25 dk",
    islenis: "Ara tatile denk gelir; 23 Kasım haftasında işlenir.",
    amac: "BM Çocuk Hakları Sözleşmesi'ndeki temel hakları günlük yaşamla ilişkilendirmek.",
    akis: ["Hak kartları (eğitim, oyun, sağlık, korunma, görüş bildirme) tahtaya yansıtılır.", "Öğrenciler her hakkın günlük hayattan bir örneğini ve bir ihlal örneğini bulur.", "Sınıf, “Çocuk Hakları Bildirgemiz” afişini hazırlar."],
    ek: {
      baslik: "HAKLARIM VE SORUMLULUKLARIM",
      yonerge: "Her hak için bir örnek ve o hakla birlikte gelen bir sorumluluk yaz.",
      bloklar: [{ t: "table", cols: ["Hakkım", "Günlük hayattan örnek", "Sorumluluğum"], rows: [["Eğitim hakkı"], ["Oyun hakkı"], ["Sağlık hakkı"], ["Görüşünü söyleme hakkı"], ["Korunma hakkı"]] }]
    }
  },
  {
    id: "ogretmenler",
    tur: "milli",
    ad: "Öğretmenler Günü",
    bas: "2026-11-24",
    bit: "2026-11-24",
    anahtar: "Öğretmenler",
    sure: "20 dk",
    amac: "Öğrenmede öğretmenin rolünü fark edip teşekkürü ifade etmek.",
    akis: ["Başöğretmen Atatürk'ün 24 Kasım 1928'deki unvanı kısaca anlatılır.", "Öğrenciler “Bana bir şey öğreten herkes öğretmenimdir” fikrini tartışır.", "Teşekkür kartı hazırlanır ve sevdikleri bir öğretmene ulaştırılır."],
    ek: {
      baslik: "TEŞEKKÜR KARTI • KES-KATLA",
      yonerge: "Ortadan katla. Ön yüzü süsle, iç yüze teşekkür mesajını yaz.",
      bloklar: [{ t: "boxes", cols: 2, h: 100, items: ["ÖN YÜZ (çizim)", "İÇ YÜZ • Sevgili öğretmenim, bana … öğrettiğiniz için teşekkür ederim."] }]
    }
  },
  {
    id: "engelliler",
    tur: "dunya",
    ad: "Dünya Engelliler Günü",
    bas: "2026-12-03",
    bit: "2026-12-03",
    anahtar: "Engelliler Günü",
    sure: "30 dk",
    amac: "Erişilebilirlik sorunlarını fark edip tasarım odaklı çözüm üretmek.",
    akis: ["Öğrenciler gözleri bantla kapalıyken kalem kutusunu açmayı dener; duygular konuşulur.", "Gruplar okulda erişilebilirliği zor olan bir yeri belirler (merdiven, lavabo, pano yüksekliği).", "Her grup bir erişilebilir tasarım önerisi çizer."],
    ek: {
      baslik: "ERİŞİLEBİLİR OKUL TASARIMI",
      yonerge: "Okulunda erişimi zor bir yer bul. Kim için zor olduğunu yaz ve bir çözüm tasarla.",
      bloklar: [{ t: "boxes", cols: 2, h: 30, items: ["Zor olan yer", "Kim için zor?"] }, { t: "boxes", cols: 1, h: 60, items: ["Tasarım önerim (çizim + açıklama)"] }]
    }
  },
  {
    id: "insanhaklari",
    tur: "dunya",
    ad: "İnsan Hakları Günü",
    bas: "2026-12-10",
    bit: "2026-12-10",
    anahtar: "İnsan Hakları",
    sure: "20 dk",
    amac: "Evrensel haklar ile kişisel sorumluluklar arasında ilişki kurmak.",
    akis: ["İnsan Hakları Evrensel Beyannamesi'nden basitleştirilmiş 6 madde gösterilir.", "Öğrenciler maddeleri “en temel”den başlayarak elmas sıralamasına dizer.", "Sıralama farklılıkları gerekçeleriyle tartışılır."],
    ek: {
      baslik: "HAK ELMASI • KES-SIRALA",
      yonerge: "Kartları kes ve elmas şeklinde sırala: en üste en temel hak, en alta en az temel bulduğun.",
      bloklar: [{ t: "cards", items: ["Yaşama hakkı", "Eğitim hakkı", "Düşünce özgürlüğü", "Eşit muamele görme", "Dinlenme ve oyun", "Barınma hakkı", "Adil yargılanma", "Seyahat özgürlüğü", "Sağlık hakkı"] }, { t: "lines", label: "En üste koyduğum hak ve nedeni:", n: 2 }]
    }
  },
  {
    id: "tutum",
    tur: "milli",
    ad: "Tutum, Yatırım ve Türk Malları Haftası",
    bas: "2026-12-12",
    bit: "2026-12-18",
    anahtar: "Tutum",
    sure: "25 dk",
    amac: "İhtiyaç-istek ayrımı yaparak bilinçli tüketim kararı vermek.",
    akis: ["Ürün kartları “ihtiyaç” ve “istek” olarak ayrılır.", "Öğrencilere sanal 100 TL verilir; bir haftalık harcama planı yapılır.", "Yerli üretim etiketleri incelenir; yerli ürün tercihinin ekonomiye etkisi konuşulur."],
    ek: {
      baslik: "100 LİRALIK HAFTA",
      yonerge: "Bir haftada 100 lira harcayabilirsin. İhtiyaç ve isteklerini planla, birikim ayır.",
      bloklar: [{ t: "table", cols: ["Harcama", "İhtiyaç mı, istek mi?", "Tutar (TL)"], rows: 6 }, { t: "boxes", cols: 2, h: 22, items: ["Toplam harcama", "Biriktirdiğim"] }]
    }
  },
  {
    id: "akif",
    tur: "milli",
    ad: "Mehmet Akif Ersoy'u Anma Haftası",
    bas: "2026-12-20",
    bit: "2026-12-27",
    anahtar: "Mehmet Akif",
    sure: "25 dk",
    amac: "İstiklal Marşı şairinin hayatından değer çıkarımı yapmak.",
    akis: ["Mehmet Akif'in İstiklal Marşı ödülünü kabul etmemesi öyküsü anlatılır.", "Öğrenciler öyküde hangi değerleri gördüklerini tartışır.", "İstiklal Marşı'ndan seçilen bir dörtlük resimle yorumlanır."],
    ek: {
      baslik: "BİR DÖRTLÜK, BİR RESİM",
      yonerge: "İstiklal Marşı'ndan seçtiğin dörtlüğü yaz ve sende uyandırdığı görüntüyü çiz.",
      bloklar: [{ t: "lines", label: "Seçtiğim dörtlük:", n: 4 }, { t: "boxes", cols: 1, h: 70, items: ["Resmim"] }, { t: "lines", label: "Mehmet Akif'in öyküsünde gördüğüm değer:", n: 1 }]
    }
  },
  {
    id: "enerji",
    tur: "milli",
    ad: "Enerji Tasarrufu Haftası",
    bas: "2027-01-11",
    bit: "2027-01-15",
    anahtar: "Enerji",
    sure: "30 dk",
    amac: "Okulda enerji israfını ölçüp tasarruf önerisi geliştirmek.",
    akis: ["Gruplar “enerji dedektifi” olarak teneffüste açık kalan ışık, priz ve pencereleri sayar.", "Sonuçlar tabloya işlenir; en çok israf olan yer bulunur.", "Her grup okul için bir tasarruf afişi ve hatırlatma etiketi tasarlar."],
    ek: {
      baslik: "ENERJİ DEDEKTİFİ RAPORU",
      yonerge: "Okulda gezip enerji israfını kaydet. Sonra bir tasarruf önerisi yaz.",
      bloklar: [{ t: "table", cols: ["Yer", "Açık ışık", "Prizde unutulan", "Açık pencere (kalorifer açıkken)"], rows: 5 }, { t: "lines", label: "Okulumuz için tasarruf önerimiz:", n: 2 }]
    }
  },
  {
    id: "yesilay",
    tur: "milli",
    ad: "Yeşilay Haftası",
    bas: "2027-03-01",
    bit: "2027-03-07",
    anahtar: "Yeşilay",
    sure: "25 dk",
    amac: "Bağımlılık yapan alışkanlıklara (ekran dâhil) karşı sağlıklı seçimler planlamak.",
    akis: ["Öğrenciler bir günlük ekran süresini tahmin eder ve sınıf ortalaması hesaplanır.", "“Ekran yerine ne yapabilirim?” etkinlik çarkı hazırlanır.", "Öğrenciler bir haftalık sağlıklı alışkanlık sözleşmesi imzalar."],
    ek: {
      baslik: "SAĞLIKLI ALIŞKANLIK ÇARKI",
      yonerge: "Çarkın her dilimine ekran yerine yapabileceğin bir etkinlik yaz. Bir haftalık takip tablonu doldur.",
      bloklar: [{ t: "boxes", cols: 4, h: 30, items: ["1", "2", "3", "4", "5", "6", "7", "8"] }, { t: "table", cols: ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"], rows: 1 }]
    }
  },
  {
    id: "istiklal",
    tur: "milli",
    ad: "İstiklal Marşı'nın Kabulü ve Mehmet Akif Ersoy'u Anma Günü",
    bas: "2027-03-12",
    bit: "2027-03-12",
    anahtar: "İstiklal Marşı",
    sure: "20 dk",
    islenis: "Ara tatile denk gelir; 15 Mart'ta işlenir.",
    amac: "İstiklal Marşı'nın yazıldığı dönemin koşullarını anlamak.",
    akis: ["1921'deki yarışma ve Meclis'te kabul süreci kısaca anlatılır.", "Öğrenciler marştaki “korkma” sözünün o günün koşullarında ne anlama geldiğini tartışır.", "Marş hep birlikte, anlamı düşünülerek okunur."],
    ek: {
      baslik: "1921'DEN BUGÜNE MESAJ",
      yonerge: "1921'de İstiklal Marşı'nı dinleyen bir askere bugünden bir mektup yaz.",
      bloklar: [{ t: "lines", label: "Sevgili kahramanım,", n: 9 }]
    }
  },
  {
    id: "canakkale",
    tur: "milli",
    ad: "Çanakkale Zaferi ve Şehitleri Anma Günü",
    bas: "2027-03-18",
    bit: "2027-03-18",
    anahtar: "Çanakkale",
    sure: "30 dk",
    amac: "Çanakkale Savaşı'nda liderlik ve dayanışma örneklerini yorumlamak.",
    akis: ["Seyit Onbaşı'nın 215 kg'lık mermiyi taşıması öyküsü anlatılır; öğrenciler “imkânsız”ın nasıl başarıldığını tartışır.", "Mustafa Kemal'in Conkbayırı'ndaki kararı liderlik açısından incelenir.", "Öğrenciler bir anma kartı ya da gelincik çiçeği tasarlar."],
    ek: {
      baslik: "ÇANAKKALE'DEN DEĞERLER",
      yonerge: "Öykülerde gördüğün değerleri yaz ve bir anma kartı tasarla.",
      bloklar: [{ t: "table", cols: ["Öykü", "Gördüğüm değer", "Bugün bu değeri nasıl yaşatırım?"], rows: [["Seyit Onbaşı"], ["Conkbayırı kararı"], ["Mehmetçik ve Anzak dostluğu"]] }, { t: "boxes", cols: 1, h: 50, items: ["Anma kartım"] }]
    }
  },
  {
    id: "orman",
    tur: "milli",
    ad: "Orman Haftası",
    bas: "2027-03-21",
    bit: "2027-03-26",
    anahtar: "Orman",
    sure: "30 dk",
    amac: "Bir ağacın ekosisteme katkılarını ölçerek değerlendirmek.",
    akis: ["Okul bahçesindeki bir ağacın gövde çevresi ölçülür ve yaşı tahmin edilir (yaklaşık 2,5 cm = 1 yıl).", "Öğrenciler ağacın verdiği hizmetleri listeler: oksijen, gölge, yuva, toprak tutma.", "Sınıf, ağaca bir kimlik kartı hazırlar."],
    ek: {
      baslik: "AĞAÇ KİMLİK KARTI",
      yonerge: "Bahçedeki bir ağacı incele, ölç ve kimlik kartını doldur.",
      bloklar: [{ t: "boxes", cols: 2, h: 26, items: ["Türü", "Gövde çevresi (cm)", "Tahmini yaşı", "Üzerinde yaşayan canlılar"] }, { t: "boxes", cols: 1, h: 50, items: ["Yaprak izi / çizimi"] }]
    }
  },
  {
    id: "su",
    tur: "dunya",
    ad: "Dünya Su Günü",
    bas: "2027-03-22",
    bit: "2027-03-22",
    anahtar: "Su Günü",
    sure: "30 dk",
    amac: "Günlük su tüketimini veriyle hesaplayıp tasarruf planı yapmak.",
    akis: ["Dişlerini fırçalarken musluk açık kalırsa kaç litre su aktığı ölçülür (1 dakikada yaklaşık 6-8 litre).", "Öğrenciler bir günlük su ayak izlerini tabloyla hesaplar.", "Sınıf su tasarrufu sözü verir ve bir hafta takip eder."],
    ek: {
      baslik: "SU AYAK İZİM",
      yonerge: "Bir günde ne kadar su kullandığını tahmini değerlerle hesapla.",
      bloklar: [{ t: "table", cols: ["Etkinlik", "Kaç kez?", "Bir seferde (L)", "Toplam (L)"], rows: [["Diş fırçalama (musluk açık)", "", "7"], ["Duş (5 dk)", "", "50"], ["Sifon", "", "8"], ["El yıkama", "", "2"], ["İçme suyu", "", "0,25"]] }, { t: "lines", label: "Tasarruf sözüm:", n: 2 }]
    }
  },
  {
    id: "kutuphane",
    tur: "milli",
    ad: "Kütüphaneler Haftası",
    bas: "2027-03-29",
    bit: "2027-04-04",
    anahtar: "Kütüphane",
    sure: "25 dk",
    amac: "Kütüphane sınıflama mantığını keşfetmek ve okuma önerisi paylaşmak.",
    akis: ["Okul kütüphanesinde rafların nasıl düzenlendiği incelenir (konu, yazar, numara).", "Gruplar sınıftaki 10 kitabı kendi kurdukları sistemle sınıflandırır.", "Her öğrenci bir arkadaşına kitap öneri kartı yazar."],
    ek: {
      baslik: "KİTAP ÖNERİ KARTI • KES",
      yonerge: "Sevdiğin bir kitabı bir arkadaşına öner. Sonunu söyleme!",
      bloklar: [{ t: "cards", blank: true, items: ["Kitap: ______ Yazar: ______ Neden okumalısın: ______ ⭐⭐⭐⭐⭐", "Kitap: ______ Yazar: ______ Neden okumalısın: ______ ⭐⭐⭐⭐⭐", "Kitap: ______ Yazar: ______ Neden okumalısın: ______ ⭐⭐⭐⭐⭐", "Kitap: ______ Yazar: ______ Neden okumalısın: ______ ⭐⭐⭐⭐⭐"] }]
    }
  },
  {
    id: "saglik",
    tur: "dunya",
    ad: "Dünya Sağlık Günü",
    bas: "2027-04-07",
    bit: "2027-04-07",
    anahtar: "Sağlık Günü",
    sure: "25 dk",
    amac: "Uyku, beslenme ve hareket verisiyle sağlıklı yaşam planı kurmak.",
    akis: ["Öğrenciler nabızlarını dinlenirken ve 1 dakika zıpladıktan sonra ölçer.", "Sonuçlar karşılaştırılır; hareketin kalbe etkisi konuşulur.", "Kişisel “sağlık üçgeni” (uyku-beslenme-hareket) hedefleri yazılır."],
    ek: {
      baslik: "NABIZ DENEYİ VE SAĞLIK ÜÇGENİM",
      yonerge: "Nabzını 15 saniye say, 4 ile çarp. Sonra sağlık hedeflerini yaz.",
      bloklar: [{ t: "table", cols: ["Durum", "15 sn sayım", "× 4 = Dakikalık nabız"], rows: [["Dinlenirken"], ["1 dk zıpladıktan sonra"], ["2 dk dinlendikten sonra"]] }, { t: "boxes", cols: 3, h: 34, items: ["UYKU hedefim", "BESLENME hedefim", "HAREKET hedefim"] }]
    }
  },
  {
    id: "turizm",
    tur: "milli",
    ad: "Turizm Haftası",
    bas: "2027-04-15",
    bit: "2027-04-22",
    anahtar: "Turizm",
    sure: "30 dk",
    amac: "Yaşadığı şehrin kültürel değerlerini tanıtan bir rota tasarlamak.",
    akis: ["Öğrenciler şehirlerinin üç önemli yerini ve bir yöresel yemeğini listeler.", "Gruplar bir yabancı turist için bir günlük gezi rotası planlar.", "Rotalar broşüre dönüştürülür ve sınıfta “turizm fuarı” yapılır."],
    ek: {
      baslik: "ŞEHRİMİN BİR GÜNLÜK ROTASI",
      yonerge: "Şehrine gelen bir turist için bir günlük gezi planla.",
      bloklar: [{ t: "table", cols: ["Saat", "Yer", "Neden görülmeli?"], rows: [["09.00"], ["11.00"], ["13.00 (öğle yemeği)"], ["15.00"], ["17.00"]] }, { t: "boxes", cols: 1, h: 40, items: ["Broşür kapağı"] }]
    }
  },
  {
    id: "23nisan",
    tur: "milli",
    ad: "Ulusal Egemenlik ve Çocuk Bayramı",
    bas: "2027-04-23",
    bit: "2027-04-23",
    anahtar: "Çocuk Bayramı",
    sure: "30 dk",
    amac: "Egemenlik ve katılım kavramlarını çocuk meclisi canlandırmasıyla deneyimlemek.",
    akis: ["TBMM'nin 23 Nisan 1920'de açılışı ve bayramın çocuklara armağan edilmesi anlatılır.", "Sınıf “Çocuk Meclisi” kurar; gruplar okul için birer kanun teklifi hazırlar.", "Teklifler oylanır; kabul edilen teklif okul yönetimine sunulur."],
    ek: {
      baslik: "ÇOCUK MECLİSİ KANUN TEKLİFİ",
      yonerge: "Okulunu daha iyi yapacak bir kanun teklifi hazırla.",
      bloklar: [{ t: "boxes", cols: 1, h: 18, items: ["Kanun teklifinin adı:"] }, { t: "boxes", cols: 2, h: 38, items: ["Hangi sorunu çözüyor?", "Madde 1-2-3"] }, { t: "table", cols: ["Kabul", "Ret", "Çekimser"], rows: 1 }]
    }
  },
  {
    id: "trafik",
    tur: "milli",
    ad: "Trafik ve İlk Yardım Haftası",
    bas: "2027-05-03",
    bit: "2027-05-07",
    anahtar: "Trafik",
    sure: "30 dk",
    amac: "Okul çevresindeki trafik risklerini haritalayıp güvenli rota çizmek.",
    akis: ["Trafik işaretleri kartlarla tanıtılır.", "Öğrenciler evden okula yollarını kroki olarak çizer, riskli noktaları kırmızıyla işaretler.", "Temel ilk yardım: 112'yi arama ve doğru bilgi verme canlandırılır."],
    ek: {
      baslik: "GÜVENLİ OKUL YOLUM",
      yonerge: "Evden okula yolunu çiz. Riskli yerleri kırmızı, güvenli geçitleri yeşil işaretle.",
      bloklar: [{ t: "boxes", cols: 1, h: 80, items: ["Rota krokim"] }, { t: "check", items: ["112'yi aradığımda adresi söylerim.", "Ne olduğunu kısa ve açık anlatırım.", "Telefonu ilk ben kapatmam."] }]
    }
  },
  {
    id: "engellilerhaftasi",
    tur: "milli",
    ad: "Engelliler Haftası",
    bas: "2027-05-10",
    bit: "2027-05-16",
    anahtar: "Engelliler Haftası",
    sure: "25 dk",
    amac: "İşaret dili ve Braille alfabesiyle farklı iletişim yollarını tanımak.",
    akis: ["Türk İşaret Dili'nde selamlaşma ve teşekkür hareketleri öğrenilir.", "Öğrenciler Braille alfabesiyle adlarını kabartma noktalarla (delikli kâğıt/boncuk) yazar.", "“Herkes için tasarım” fikri bir örnekle tartışılır."],
    ek: {
      baslik: "ADIM BRAILLE'DA",
      yonerge: "Braille tablosunu kullanarak adını noktalarla yaz. Noktaları kalemle kabartabilirsin.",
      bloklar: [{ t: "boxes", cols: 6, h: 30, items: ["1. harf", "2. harf", "3. harf", "4. harf", "5. harf", "6. harf"] }, { t: "lines", label: "Öğrendiğim işaret dili kelimeleri:", n: 2 }]
    }
  },
  {
    id: "19mayis",
    tur: "milli",
    ad: "Atatürk'ü Anma, Gençlik ve Spor Bayramı",
    bas: "2027-05-19",
    bit: "2027-05-19",
    anahtar: "Gençlik ve Spor",
    sure: "25 dk",
    islenis: "Kurban Bayramı tatiline denk gelir; 20-21 Mayıs'ta işlenir.",
    amac: "Atatürk'ün Samsun yolculuğunu harita ve zaman çizgisiyle izlemek.",
    akis: ["Bandırma Vapuru'nun İstanbul'dan Samsun'a rotası haritada çizilir.", "Samsun-Havza-Amasya-Erzurum-Sivas-Ankara yolculuğu zaman çizgisine dizilir.", "Atatürk'ün gençliğe hitabesinden bir cümle seçilip bugüne uyarlanır."],
    ek: {
      baslik: "SAMSUN'DAN ANKARA'YA",
      yonerge: "Olayları tarih sırasına diz ve her durağın önemini bir cümleyle yaz.",
      bloklar: [{ t: "table", cols: ["Tarih", "Yer", "Ne oldu?"], rows: [["19 Mayıs 1919", "Samsun"], ["", "Havza"], ["", "Amasya"], ["", "Erzurum"], ["", "Sivas"], ["27 Aralık 1919", "Ankara"]] }]
    }
  },
  {
    id: "cevre",
    tur: "milli",
    ad: "Çevre Koruma Haftası",
    bas: "2027-06-07",
    bit: "2027-06-11",
    anahtar: "Çevre Koruma",
    sure: "30 dk",
    amac: "Sınıf atıklarını sınıflandırıp azaltma planı yapmak.",
    akis: ["Bir günlük sınıf çöpü (temiz atıklar) türlerine ayrılıp tartılır.", "Gruplar en çok çıkan atık türü için azalt-yeniden kullan-geri dönüştür önerisi geliştirir.", "Sınıfa atık ayrıştırma kutuları için etiketler tasarlanır."],
    ek: {
      baslik: "SINIF ATIK DENETİMİ",
      yonerge: "Atıkları türlerine ayır, say ya da tart. Sonra azaltma planını yaz.",
      bloklar: [{ t: "table", cols: ["Atık türü", "Adet / gram", "Azalt", "Yeniden kullan", "Geri dönüştür"], rows: [["Kâğıt"], ["Plastik"], ["Metal"], ["Organik"], ["Diğer"]] }]
    }
  },
  // ---------------- Avrupa Birliği ve uluslararası eğitim etkinlikleri ----------------
  {
    id: "mobilite",
    tur: "ab",
    ad: "Avrupa Hareketlilik Haftası (#MobilityWeek)",
    bas: "2026-09-16",
    bit: "2026-09-22",
    sure: "25 dk",
    link: "https://mobilityweek.eu",
    teyit: true,
    amac: "Okula ulaşım biçimlerini veriyle inceleyip sürdürülebilir ulaşım önermek.",
    akis: ["Sınıfta “Okula nasıl geldin?” çetelesi tutulur ve grafiğe dönüştürülür.", "Her ulaşım türünün artısı-eksisi (zaman, sağlık, çevre) tartışılır.", "“Okula yürüyüş günü” için bir davet afişi hazırlanır."],
    ek: {
      baslik: "OKULA NASIL GELİYORUZ?",
      yonerge: "Sınıfın ulaşım verisini topla, grafiğe dönüştür, bir öneri yaz.",
      bloklar: [{ t: "table", cols: ["Yürüyerek", "Bisiklet/scooter", "Servis", "Toplu taşıma", "Özel araç"], rows: 2 }, { t: "boxes", cols: 1, h: 50, items: ["Sütun grafiği"] }, { t: "lines", label: "Sürdürülebilir ulaşım önerimiz:", n: 2 }]
    }
  },
  {
    id: "spor",
    tur: "ab",
    ad: "Avrupa Spor Haftası (#BeActive)",
    bas: "2026-09-23",
    bit: "2026-09-30",
    sure: "20 dk",
    link: "https://sport.ec.europa.eu/initiatives/european-week-of-sport",
    teyit: true,
    amac: "Hareketi öğrenmeye katmak; beden ve zihin ilişkisini fark etmek.",
    akis: ["Ders başında 3 dakikalık “beyin jimnastiği” (çapraz hareketler) yapılır.", "Öğrenciler hareketten önce ve sonra kısa bir hafıza testi çözer, sonuçlar karşılaştırılır.", "Sınıf kendi 1 dakikalık #BeActive hareket dizisini tasarlar."],
    ek: {
      baslik: "HAREKET ET, HATIRLA",
      yonerge: "Hareketten önce ve sonra 10 kelimeyi 30 saniye incele; hatırladıklarını yaz.",
      bloklar: [{ t: "boxes", cols: 2, h: 50, items: ["Hareketten ÖNCE hatırladıklarım", "Hareketten SONRA hatırladıklarım"] }, { t: "boxes", cols: 4, h: 30, items: ["1. hareket", "2. hareket", "3. hareket", "4. hareket"] }]
    }
  },
  {
    id: "arastirmacigecesi",
    tur: "ab",
    ad: "Avrupa Araştırmacılar Gecesi",
    bas: "2026-09-25",
    bit: "2026-09-25",
    sure: "30 dk",
    link: "https://marie-sklodowska-curie-actions.ec.europa.eu/event/european-researchers-night",
    teyit: false,
    amac: "Bilim insanlarının çalışma hayatını tanımak; “bilim insanına soru” hazırlamak.",
    akis: ["Marie Skłodowska-Curie'nin hayatı kısaca anlatılır (iki Nobel kazanan ilk kişi).", "Öğrenciler bir bilim insanına sormak istedikleri soruları yazar.", "Sorular, yakındaki bir üniversite etkinliğine ya da çevrim içi bilim insanı görüşmesine gönderilmek üzere seçilir."],
    ek: {
      baslik: "BİR BİLİM İNSANINA SORUM VAR",
      yonerge: "Merak ettiğin bir alandaki bilim insanına sorularını yaz.",
      bloklar: [{ t: "boxes", cols: 1, h: 16, items: ["Hangi alandaki bilim insanı?"] }, { t: "lines", label: "Sorularım:", n: 5 }, { t: "boxes", cols: 1, h: 40, items: ["Bir bilim insanını çiz (laboratuvar dışında da olabilir!)"] }]
    }
  },
  {
    id: "diller",
    tur: "ab",
    ad: "Avrupa Diller Günü",
    bas: "2026-09-26",
    bit: "2026-09-26",
    islenis: "25 Eylül Cuma",
    sure: "25 dk",
    link: "https://edl.ecml.at",
    teyit: true,
    amac: "Diller arasındaki ortak kelimeleri ve iletişim örüntülerini keşfetmek.",
    akis: ["“Merhaba” kelimesi 8 dilde tahtaya yazılır; öğrenciler hangi dillerin birbirine benzediğini tahmin eder.", "Türkçeden Avrupa dillerine geçmiş kelimeler (yoğurt, kiosk/köşk, divan) ve tersi aranır.", "Öğrenciler kendi “mini sözlük kartı”nı hazırlar."],
    ek: {
      baslik: "KELİMELERİN YOLCULUĞU",
      yonerge: "Kelimelerin farklı dillerdeki hâllerini yaz ve benzerlikleri işaretle.",
      bloklar: [{ t: "table", cols: ["Türkçe", "İngilizce", "Almanca", "Fransızca", "Başka bir dil"], rows: [["merhaba"], ["teşekkürler"], ["yoğurt"], ["kahve"], ["okul"]] }, { t: "lines", label: "Fark ettiğim örüntü:", n: 2 }]
    }
  },
  {
    id: "uzayhaftasi",
    tur: "dunya",
    ad: "Dünya Uzay Haftası (BM)",
    bas: "2026-10-04",
    bit: "2026-10-10",
    sure: "30 dk",
    link: "https://www.worldspaceweek.org",
    teyit: true,
    amac: "Uydu teknolojisinin günlük hayattaki yerini fark etmek.",
    akis: ["Sputnik (4 Ekim 1957) ve Türkiye'nin uyduları (Türksat, İMECE) tanıtılır.", "Öğrenciler bir gününde uyduya bağlı hizmetleri listeler: harita, hava durumu, televizyon.", "Gruplar okulları için bir “sınıf uydusu”nun görevini tasarlar."],
    ek: {
      baslik: "UYDUSUZ BİR GÜN",
      yonerge: "Uydular bir gün çalışmasaydı hayatında neler değişirdi? Sonra kendi uydunu tasarla.",
      bloklar: [{ t: "table", cols: ["Hizmet", "Uydu nasıl yardım ediyor?", "Uydu olmasaydı …"], rows: [["Harita / navigasyon"], ["Hava durumu"], ["Televizyon"], ["Afet takibi"]] }, { t: "boxes", cols: 1, h: 46, items: ["Uydumun adı ve görevi (çizim)"] }]
    }
  },
  {
    id: "codeweek",
    tur: "ab",
    ad: "AB Kod Haftası (EU Code Week)",
    bas: "2026-10-10",
    bit: "2026-10-25",
    sure: "40 dk",
    link: "https://codeweek.eu",
    teyit: true,
    amac: "Bilgisayarsız (unplugged) kodlamayla algoritmik düşünmeyi geliştirmek; etkinliği Code Week haritasına kaydetmek.",
    akis: ["Sınıf zemine bantla 5×5 ızgara çizilir; bir öğrenci “robot”, diğerleri “programcı” olur.", "Gruplar Ek'teki ok kartlarıyla robotu hedefe götüren algoritmayı yazar; hata ayıklama (debug) yapılır.", "Etkinlik fotoğraflanır ve codeweek.eu üzerinden etkinlik haritasına eklenir; katılım sertifikası alınır. (2026 dönemi geçti; aynı etkinlik Hour of Code haftasında ya da 2027 Kod Haftası'nda yapılabilir.)"],
    ek: {
      baslik: "ROBOTU HEDEFE GÖTÜR • UNPLUGGED KODLAMA",
      yonerge: "Robot ★'dan başlıyor. Engellere çarpmadan bayrağa ulaştıran komutları yaz. Ok kartlarını kesip kullanabilirsin.",
      bloklar: [{ t: "grid", n: 6, marks: { "0,0": "★", "5,5": "⚑", "1,2": "■", "3,1": "■", "3,3": "■", "4,4": "■", "2,4": "■" } }, { t: "cards", items: ["↑ İleri", "↑ İleri", "↑ İleri", "↷ Sağa dön", "↷ Sağa dön", "↶ Sola dön", "↶ Sola dön", "⟳ Tekrarla ×2", "⟳ Tekrarla ×3"] }, { t: "lines", label: "Algoritmam:", n: 2 }]
    }
  },
  {
    id: "erasmusdays",
    tur: "ab",
    ad: "Erasmus Günleri (#ErasmusDays)",
    bas: "2026-10-15",
    bit: "2026-10-17",
    sure: "25 dk",
    link: "https://www.erasmusdays.eu",
    teyit: false,
    amac: "Avrupa'da eğitim hareketliliği ve eTwinning ortaklıklarını tanımak.",
    akis: ["Erasmus+ ve eTwinning'in ne olduğu, Türk okullarının katıldığı örnek projeler üzerinden anlatılır.", "Öğrenciler bir Avrupa okuluna tanıtacakları “sınıf kimlik kartı” hazırlar.", "Kartlar eTwinning ortağı bir sınıfla paylaşılmak üzere saklanır."],
    ek: {
      baslik: "SINIFIMIZIN AVRUPA KİMLİK KARTI",
      yonerge: "Avrupa'daki ortak bir sınıfa kendinizi tanıtın.",
      bloklar: [{ t: "boxes", cols: 2, h: 34, items: ["Şehrimiz ve okulumuz", "BİLSEM'de neler yapıyoruz?", "Sevdiğimiz oyunlar", "Ortak proje fikrimiz"] }, { t: "lines", label: "Merhaba! (İngilizce kısa mesajımız)", n: 3 }]
    }
  },
  {
    id: "robotik",
    tur: "ab",
    ad: "Avrupa Robotik Haftası (ERW)",
    bas: "2026-11-23",
    bit: "2026-11-27",
    sure: "40 dk",
    link: "https://eu-robotics.net/european-robotics-week/",
    teyit: false,
    amac: "Robotların algıla-düşün-hareket et döngüsünü basit bir model üzerinde keşfetmek. (2026 tarihi Kasım olarak duyuruldu; kesin gün açıklanınca kontrol edin.)",
    akis: ["Robot süpürge, fabrika kolu ve Mars aracının ortak noktaları (sensör, işlemci, motor) bulunur.", "Gruplar karton, pipet ve ip ile bir “robot el” yapar; parmakların nasıl büküldüğünü gözlemler.", "Öğrenciler kendi robotlarının algıla-düşün-hareket et kartını doldurur."],
    ek: {
      baslik: "ROBOTUMU TASARLIYORUM",
      yonerge: "Bir problemi çözecek robotunu tasarla. Robotun neyi algılayacağını, neye karar vereceğini ve nasıl hareket edeceğini yaz.",
      bloklar: [{ t: "boxes", cols: 3, h: 40, items: ["ALGILA (sensör)", "DÜŞÜN (karar)", "HAREKET ET (motor)"] }, { t: "boxes", cols: 1, h: 60, items: ["Robotumun çizimi"] }]
    }
  },
  {
    id: "hourofcode",
    tur: "dunya",
    ad: "Bilgisayar Bilimi Eğitim Haftası (Hour of Code / Hour of AI)",
    bas: "2026-12-07",
    bit: "2026-12-13",
    sure: "40 dk",
    link: "https://hourofcode.com",
    teyit: false,
    amac: "Bir saatlik kodlama etkinliğiyle döngü ve koşul kavramlarını uygulamak.",
    akis: ["code.org'daki “Hour of Code / Hour of AI” etkinliklerinden yaşa uygun biri seçilir (çevrim dışı seçenekler de var).", "Bilgisayar yoksa: Ek'teki dans algoritması kartlarıyla döngü (tekrarla) ve koşul (eğer) uygulanır.", "Öğrenciler ürettikleri algoritmayı bir arkadaşına “çalıştırtır”."],
    ek: {
      baslik: "DANS ALGORİTMASI • DÖNGÜ VE KOŞUL",
      yonerge: "Bir dans algoritması yaz. En az bir “tekrarla” ve bir “eğer” kullan.",
      bloklar: [{ t: "cards", items: ["👏 Alkışla", "🦶 Ayağını vur", "🙌 Kollarını kaldır", "↻ Dön", "⟳ TEKRARLA 2 kez", "⟳ TEKRARLA 3 kez", "❓ EĞER müzik hızlıysa", "❓ DEĞİLSE"] }, { t: "lines", label: "Algoritmam:", n: 4 }]
    }
  },
  {
    id: "guvenliinternet",
    tur: "ab",
    ad: "Güvenli İnternet Günü (Safer Internet Day)",
    bas: "2027-02-09",
    bit: "2027-02-09",
    sure: "40 dk",
    link: "https://better-internet-for-kids.europa.eu",
    teyit: true,
    amac: "Yapay zekâ çağında dijital içeriği sorgulama ve güvenli paylaşım alışkanlığı geliştirmek (2027 teması: akıllı teknoloji, güvenli seçimler).",
    akis: ["Öğrencilere üç görsel gösterilir; hangisinin yapay zekâyla üretildiğini tahmin ederler ve ipuçlarını tartışırlar.", "“Dur-Düşün-Sor” kuralı ile bir paylaşımı göndermeden önceki üç kontrol öğrenilir.", "Sınıf, Güvenli İnternet sözleşmesi yazar; etkinlik saferinternetday.org'a kaydedilebilir."],
    ek: {
      baslik: "DUR • DÜŞÜN • SOR",
      yonerge: "Her durumu oku. Ne yapacağını seç ve nedenini yaz.",
      bloklar: [{ t: "table", cols: ["Durum", "Ne yaparım?", "Neden?"], rows: [["Tanımadığım biri oyunda adresimi sordu."], ["Ünlü birinin şaşırtıcı bir videosu yayılıyor."], ["Arkadaşımın komik fotoğrafını izinsiz paylaşmak istiyorum."], ["Bir uygulama ödevimi yapay zekâyla yapmayı öneriyor."]] }, { t: "lines", label: "Sınıfımızın güvenli internet sözü:", n: 2 }]
    }
  },
  {
    id: "bilimdekadin",
    tur: "dunya",
    ad: "Bilimde Kadınlar ve Kız Çocukları Günü (BM)",
    bas: "2027-02-11",
    bit: "2027-02-11",
    sure: "25 dk",
    link: "https://www.un.org/en/observances/women-and-girls-in-science-day",
    teyit: true,
    amac: "Bilime katkı yapmış kadın bilim insanlarını tanımak ve kalıp yargıları sorgulamak.",
    akis: ["Öğrencilerden “bir bilim insanı” çizmeleri istenir; çizimlerdeki ortak özellikler konuşulur.", "Gruplar kadın bilim insanı kartlarını (Türkan Saylan, Ada Lovelace, Marie Curie, Canan Dağdeviren, Katherine Johnson) inceler.", "Her grup seçtiği bilim insanı için “keşif kartı” hazırlar."],
    ek: {
      baslik: "BİLİM İNSANI KEŞİF KARTI",
      yonerge: "Seçtiğin kadın bilim insanını araştır ve kartını doldur.",
      bloklar: [{ t: "boxes", cols: 2, h: 30, items: ["Adı ve ülkesi", "Bilim alanı", "En önemli çalışması", "Karşılaştığı zorluk"] }, { t: "lines", label: "Ondan öğrendiğim:", n: 2 }]
    }
  },
  {
    id: "anadil",
    tur: "dunya",
    ad: "Uluslararası Anadili Günü (UNESCO)",
    bas: "2027-02-21",
    bit: "2027-02-21",
    islenis: "19 Şubat Cuma",
    sure: "20 dk",
    link: "https://www.unesco.org/en/days/mother-language",
    teyit: true,
    amac: "Türkçenin zenginliğini deyim ve atasözleri üzerinden fark etmek.",
    akis: ["Öğrenciler başka dillere çevrilemeyen Türkçe kelimeler bulur (gönül, hasret, yakamoz).", "Deyim kartları resmedilir; sınıf resimden deyimi tahmin eder.", "Her öğrenci sevdiği bir Türkçe kelimeyi tanımlayan bir kart yazar."],
    ek: {
      baslik: "DEYİMİ ÇİZ, ARKADAŞIN BULSUN",
      yonerge: "Bir deyim seç ve kelimesi kelimesine çiz. Arkadaşın çizimden deyimi tahmin etsin.",
      bloklar: [{ t: "boxes", cols: 2, h: 70, items: ["Çizimim", "Deyim ve gerçek anlamı"] }, { t: "lines", label: "Başka dile çevrilemeyen sevdiğim kelime:", n: 1 }]
    }
  },
  {
    id: "piday",
    tur: "dunya",
    ad: "Uluslararası Matematik Günü / Pi Günü (UNESCO)",
    bas: "2027-03-14",
    bit: "2027-03-14",
    islenis: "15 Mart Pazartesi",
    sure: "40 dk",
    link: "https://www.idm314.org",
    teyit: true,
    amac: "Pi sayısını ölçerek keşfetmek.",
    akis: ["Gruplar daire biçimli nesnelerin (bardak, tabak, kapak) çevresini iple, çapını cetvelle ölçer.", "Çevre ÷ çap hesaplanır; sonuçların hep 3'ten biraz büyük çıktığı fark edilir.", "Sınıf ortalaması π ile karşılaştırılır; π'nin rakamlarıyla “pi zinciri” yapılır."],
    ek: {
      baslik: "PI'Yİ ÖLÇEREK BUL",
      yonerge: "Daire şeklindeki nesneleri ölç. Çevreyi çapa böl. Ne fark ediyorsun?",
      bloklar: [{ t: "table", cols: ["Nesne", "Çevre (cm)", "Çap (cm)", "Çevre ÷ Çap"], rows: 5 }, { t: "boxes", cols: 2, h: 22, items: ["Sınıf ortalamamız", "π ≈ 3,14159…"] }, { t: "lines", label: "Fark ettiğim:", n: 2 }]
    }
  },
  {
    id: "parahaftasi",
    tur: "dunya",
    ad: "Küresel Para Haftası (Global Money Week)",
    bas: "2027-03-15",
    bit: "2027-03-19",
    sure: "30 dk",
    link: "https://globalmoneyweek.org",
    teyit: false,
    amac: "Birikim, bütçe ve hedef kavramlarını oyunla uygulamak. (OECD tarihleri her yıl duyurur; kontrol edin.)",
    akis: ["Öğrenciler bir hedef seçer (kitap, oyuncak) ve kaç hafta biriktirmesi gerektiğini hesaplar.", "“Pazar yeri” oyununda sanal paralarla alım-satım yapılır.", "Faiz kavramı basit bir örnekle (kumbara + bonus) gösterilir."],
    ek: {
      baslik: "BİRİKİM HEDEF PLANIM",
      yonerge: "Bir hedef seç ve birikim planını hesapla.",
      bloklar: [{ t: "boxes", cols: 3, h: 26, items: ["Hedefim", "Fiyatı (TL)", "Haftalık biriktireceğim (TL)"] }, { t: "table", cols: ["Hafta", "Biriktirdiğim", "Toplam"], rows: 6 }]
    }
  },
  {
    id: "earthhour",
    tur: "dunya",
    ad: "Dünya Saati (Earth Hour)",
    bas: "2027-03-27",
    bit: "2027-03-27",
    islenis: "26 Mart Cuma (hazırlık)",
    sure: "25 dk",
    link: "https://www.earthhour.org",
    teyit: true,
    amac: "Enerji tüketimi ve iklim ilişkisini fark etmek; aileyle bir saatlik eylem planlamak.",
    akis: ["Sınıfın ışıkları 5 dakika kapatılır; karanlıkta neler yapabileceğimiz konuşulur.", "Öğrenciler 27 Mart akşamı ailesiyle ışıksız bir saat için etkinlik planı yapar.", "Pazartesi günü deneyimler paylaşılır."],
    ek: {
      baslik: "IŞIKSIZ BİR SAAT PLANIM",
      yonerge: "27 Mart 20.30-21.30 arasında ailenle ne yapacağını planla. Sonra deneyimini yaz.",
      bloklar: [{ t: "boxes", cols: 2, h: 40, items: ["Planımız", "Neler oldu? (sonradan)"] }, { t: "check", items: ["Gereksiz ışıkları kapattık.", "Prizdeki şarj aletlerini çıkardık.", "Ailemle bir oyun oynadık / hikâye anlattık."] }]
    }
  },
  {
    id: "yaraticilik",
    tur: "dunya",
    ad: "Dünya Yaratıcılık ve İnovasyon Günü (BM)",
    bas: "2027-04-21",
    bit: "2027-04-21",
    sure: "25 dk",
    link: "https://www.un.org/en/observances/creativity-and-innovation-day",
    teyit: true,
    amac: "Sıradan bir nesne için SCAMPER ile yeni kullanım fikirleri üretmek.",
    akis: ["Bir ataş gösterilir; öğrenciler 2 dakikada mümkün olduğunca çok kullanım alanı yazar.", "SCAMPER sorularıyla (yerine koy, birleştir, uyarla…) fikir sayısı artırılır.", "En sıra dışı fikir sınıf oylamasıyla seçilir."],
    ek: {
      baslik: "SCAMPER İLE YENİDEN TASARLA",
      yonerge: "Seçtiğin nesneyi her soruyla yeniden düşün.",
      bloklar: [{ t: "table", cols: ["SCAMPER", "Soru", "Fikrim"], rows: [["S", "Yerine ne koyabilirim?"], ["C", "Neyle birleştirebilirim?"], ["A", "Başka nereye uyarlayabilirim?"], ["M", "Büyütür / küçültürsem?"], ["P", "Başka ne için kullanırım?"], ["E", "Neyi çıkarabilirim?"], ["R", "Tersine çevirirsem?"]] }]
    }
  },
  {
    id: "dunyagunu",
    tur: "dunya",
    ad: "Dünya Günü (Earth Day)",
    bas: "2027-04-22",
    bit: "2027-04-22",
    sure: "25 dk",
    link: "https://www.earthday.org",
    teyit: true,
    amac: "Gezegenin ortak sorunları için kişisel bir eylem taahhüdü vermek.",
    akis: ["Uzaydan çekilmiş Dünya fotoğrafı (“Mavi Bilye”) gösterilir.", "Gruplar bir çevre sorununu seçip sebep-sonuç zinciri kurar.", "Her öğrenci bir aylık “Dünya sözü” yazar."],
    ek: {
      baslik: "SEBEP-SONUÇ ZİNCİRİ",
      yonerge: "Bir çevre sorununun sebeplerini ve sonuçlarını zincir gibi bağla.",
      bloklar: [{ t: "boxes", cols: 5, h: 34, items: ["Sebep", "→", "Sorun", "→", "Sonuç"] }, { t: "lines", label: "Bir aylık Dünya sözüm:", n: 2 }]
    }
  },
  {
    id: "kitapgunu",
    tur: "dunya",
    ad: "Dünya Kitap ve Telif Hakkı Günü (UNESCO)",
    bas: "2027-04-23",
    bit: "2027-04-23",
    islenis: "22 Nisan (23 Nisan bayram)",
    sure: "20 dk",
    link: "https://www.unesco.org/en/days/world-book-and-copyright",
    teyit: true,
    amac: "Bir eserin sahibinin emeğini ve telif kavramını anlamak.",
    akis: ["Bir öğrencinin resmi izinsiz başka bir isimle sergilenirse ne hissedeceği konuşulur.", "Telif hakkı ve kaynak gösterme bağlantısı kurulur.", "Öğrenciler kendi kısa hikâyeleri için “telif sayfası” (yazar, tarih, izin) hazırlar."],
    ek: {
      baslik: "KENDİ KİTABIMIN KÜNYESİ",
      yonerge: "Bir mini hikâye yaz ve kitabının künye sayfasını hazırla.",
      bloklar: [{ t: "boxes", cols: 2, h: 26, items: ["Kitabın adı", "Yazar / çizer", "Yayın tarihi", "Kimler kullanabilir? (izin)"] }, { t: "lines", label: "Mini hikâyem:", n: 6 }]
    }
  },
  {
    id: "fikrimulkiyet",
    tur: "dunya",
    ad: "Dünya Fikrî Mülkiyet Günü (WIPO)",
    bas: "2027-04-26",
    bit: "2027-04-26",
    sure: "25 dk",
    link: "https://www.wipo.int/ip-outreach/en/ipday/",
    teyit: true,
    amac: "Patent, marka ve tasarım tescili kavramlarını buluşlarla ilişkilendirmek.",
    akis: ["Gündelik ürünlerde patent, marka ve tasarım örnekleri bulunur.", "Öğrenciler kendi buluş fikri için basit bir “patent başvuru formu” doldurur.", "Türk Patent ve Marka Kurumu'nun görevi kısaca tanıtılır."],
    ek: {
      baslik: "MİNİ PATENT BAŞVURUM",
      yonerge: "Buluşunu bir patent başvurusu gibi anlat.",
      bloklar: [{ t: "boxes", cols: 2, h: 28, items: ["Buluşun adı", "Mucit(ler)", "Çözdüğü problem", "Benzerlerinden farkı"] }, { t: "boxes", cols: 1, h: 50, items: ["Teknik çizim"] }]
    }
  },
  {
    id: "avrupagunu",
    tur: "ab",
    ad: "Avrupa Günü",
    bas: "2027-05-09",
    bit: "2027-05-09",
    islenis: "7 Mayıs Cuma",
    sure: "25 dk",
    link: "https://european-union.europa.eu/principles-countries-history/symbols/europe-day_tr",
    teyit: true,
    amac: "Uluslararası iş birliğinin bilim ve eğitim projelerine katkısını tanımak.",
    akis: ["9 Mayıs 1950 Schuman Bildirgesi'nin “savaş yerine iş birliği” fikri anlatılır.", "Avrupa ülkeleri ile Türkiye'nin ortak yürüttüğü bilim projeleri (CERN, Erasmus+, eTwinning, Horizon) örneklenir.", "Gruplar Avrupa'daki bir okulla yapılabilecek ortak proje fikri yazar."],
    ek: {
      baslik: "ORTAK PROJE FİKRİMİZ",
      yonerge: "Avrupa'daki bir okulla birlikte yapabileceğiniz bir bilim projesi tasarlayın.",
      bloklar: [{ t: "boxes", cols: 2, h: 30, items: ["Proje adı", "Ortak ülke / okul", "Biz ne yapacağız?", "Onlar ne yapacak?"] }, { t: "lines", label: "Projeden ikimizin de öğreneceği:", n: 2 }]
    }
  },
  {
    id: "arigunu",
    tur: "dunya",
    ad: "Dünya Arı Günü (BM)",
    bas: "2027-05-20",
    bit: "2027-05-20",
    sure: "25 dk",
    link: "https://www.un.org/en/observances/bee-day",
    teyit: true,
    amac: "Tozlaşmanın gıda zincirindeki önemini fark etmek; altıgen örüntüyü keşfetmek.",
    akis: ["Arılar olmasaydı kahvaltı sofrasından hangi gıdaların eksileceği tahmin edilir.", "Petek altıgenlerinin neden boşluksuz yan yana geldiği kâğıt şekillerle denenir (üçgen, kare, altıgen, beşgen).", "Gruplar okul bahçesi için arı dostu bir köşe tasarlar."],
    ek: {
      baslik: "PETEK NEDEN ALTIGEN?",
      yonerge: "Şekilleri boşluk bırakmadan yan yana dizmeyi dene. Hangileri başarılı oldu?",
      bloklar: [{ t: "table", cols: ["Şekil", "Boşluksuz dizilebildi mi?", "Not"], rows: [["Üçgen"], ["Kare"], ["Beşgen"], ["Altıgen"], ["Daire"]] }, { t: "lines", label: "Arılar olmasaydı kahvaltımızdan eksilecekler:", n: 2 }]
    }
  },
  {
    id: "cevregunu",
    tur: "dunya",
    ad: "Dünya Çevre Günü (BM)",
    bas: "2027-06-05",
    bit: "2027-06-05",
    islenis: "4 Haziran Cuma",
    sure: "25 dk",
    link: "https://www.worldenvironmentday.global",
    teyit: true,
    amac: "Plastik kirliliği ve atık azaltma için yaratıcı çözümler üretmek.",
    akis: ["Bir plastik şişenin doğada ne kadar sürede yok olduğu (yaklaşık 450 yıl) zaman çizgisinde gösterilir.", "Gruplar tek kullanımlık bir ürüne alternatif tasarlar.", "Tasarımlar “Yeşil Fikirler” panosunda sergilenir."],
    ek: {
      baslik: "TEK KULLANIMLIĞA ALTERNATİF",
      yonerge: "Bir tek kullanımlık ürün seç ve yeniden kullanılabilir alternatifini tasarla.",
      bloklar: [{ t: "boxes", cols: 2, h: 60, items: ["Tek kullanımlık ürün (çizim)", "Benim alternatifim (çizim)"] }, { t: "lines", label: "Alternatifimin faydası:", n: 2 }]
    }
  },
  {
    id: "okyanus",
    tur: "dunya",
    ad: "Dünya Okyanuslar Günü (BM)",
    bas: "2027-06-08",
    bit: "2027-06-08",
    sure: "20 dk",
    link: "https://www.un.org/en/observances/oceans-day",
    teyit: true,
    amac: "Denizlerin iklim ve canlılık için önemini veriyle tartışmak.",
    akis: ["Dünya yüzeyinin yaklaşık %71'inin su olduğu küre üzerinde gösterilir.", "Öğrenciler kendi denizlerimizdeki (Karadeniz, Marmara, Ege, Akdeniz) bir sorunu araştırır (müsilaj, aşırı avlanma).", "Gruplar bir deniz canlısının ağzından “yardım mektubu” yazar."],
    ek: {
      baslik: "DENİZDEN BİR MEKTUP",
      yonerge: "Bir deniz canlısı seç. Onun ağzından insanlara bir mektup yaz.",
      bloklar: [{ t: "boxes", cols: 2, h: 22, items: ["Ben bir …", "Yaşadığım deniz"] }, { t: "lines", label: "Sevgili insanlar,", n: 7 }]
    }
  },
  {
    id: "yesilhafta",
    tur: "ab",
    ad: "AB Yeşil Haftası (EU Green Week)",
    bas: "2027-06-07",
    bit: "2027-06-11",
    sure: "30 dk",
    link: "https://green-week.event.europa.eu",
    teyit: false,
    amac: "Avrupa Yeşil Mutabakatı'nın hedeflerini okul ölçeğine indirgemek. (Tarih AB tarafından her yıl duyurulur; kontrol edin.)",
    akis: ["“2050'de iklim nötr kıta” hedefi basitçe anlatılır.", "Öğrenciler okulun karbon ayak izini oluşturan kaynakları listeler (ısınma, ulaşım, kâğıt, yemek).", "Sınıf, “Yeşil Okul 2030” için üç hedef belirler."],
    ek: {
      baslik: "YEŞİL OKUL 2030 HEDEFLERİMİZ",
      yonerge: "Okulun çevreye etkisini oluşturan kaynakları yaz ve her biri için bir hedef koy.",
      bloklar: [{ t: "table", cols: ["Kaynak", "Bugün", "2030 hedefimiz", "İlk adım"], rows: [["Isınma"], ["Ulaşım"], ["Kâğıt"], ["Yemek atığı"]] }]
    }
  }
];
