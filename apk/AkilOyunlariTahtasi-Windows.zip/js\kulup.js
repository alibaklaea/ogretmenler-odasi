(function() {
  const yt = (q) => "https://www.youtube.com/results?search_query=" + encodeURIComponent(q);
  const v = (ad, src) => ({ ad, src: "video/" + src });
  const y = (ad, ara) => ({ ad, yt: yt(ara) });
  window.KULUP = {
    okul: "Bucuk İlkokulu Çocuk Kulübü",
    baslangic: "2026-10-31",
    // her Cumartesi
    programlar: {
      AKIL: {
        ad: "Akıl Oyunları",
        blok: "1. Blok",
        ogretmen: "Ali Bakla",
        saatler: [["08.30 – 09.50", "1. – 2. ders"], ["09.50 – 10.00", "Teneffüs"], ["10.00 – 10.40", "3. ders"]],
        haftalar: [
          {
            ad: "Tanışma: Pentago ve Küre (tahtada ve kâğıtta)",
            oyunlar: ["Pentago", "Küre"],
            oyunsuz: true,
            hedef: "Pentago ve Küre'nin tahtasını, taşlarını ve kurallarını tanıyacağız.",
            amac: "Oyun takımı olmadan, akıllı tahta ve çıktılarla Pentago ile Küre'nin tahtasını, taşlarını ve temel kurallarını öğrenir; kural kâğıtlarını çözer.",
            dersler: [
              ["Tanışma ve kulüp kuralları (10 dk)", "Çember olun. Herkes adını ve en sevdiği oyunu söyler. Kulüp kuralları: sırayla konuş, eşine saygı göster, kaybeden de kazanan da el sıkışır. Bugün takım yok; tahta ve kâğıtla çalışacağımızı söyleyin."],
              ["Pentago kuralları tahtada (15 dk)", "Pentago'nun 3 kural videosunu izleyin, ardından TAZOF kural slaytlarını madde madde okuyun. Her slaytta sorun: 'Kim başlar?', 'Tabla kaç derece döner?', 'Beşi yapınca çevirmek gerekir mi?', 'İkimiz de beş olursak ne olur?'"],
              ["Pentago: önce birlikte, sonra kâğıt (55 dk)", "Her kâğıttan önce sunumdaki Birlikte yapalım sorularını çözün: bir öğrenci tahtaya gelip gösterir, sınıf 'doğru mu?' der, sonra Cevabı göster'e basın. Ardından aynı türdeki kâğıda geçin: Tablalar ve çukurlar, Tablayı çevir, Beşli avı."],
              ["3. ders: Küre kuralları tahtada (10 dk)", "Ajan taş videosunu izleyin, TAZOF kural slaytlarını okuyun. Vurgu: mor başlar, ileri, geri ve çapraz 1 kare gidilir, yana gidilmez."],
              ["3. ders: Küre, önce birlikte, sonra kâğıt (25 dk)", "Sunumdaki Birlikte yapalım sorularını çözün, sonra kâğıda geçin: Diziliş ve ajan taş, Başlangıç sırası, Ortadaki taş. Bitiremeyen öğrenci haftaya devam eder."],
              ["Çıkış bileti (5 dk)", "Her öğrenci 'Bugün en çok hangi kuralı öğrendim?' sorusunu söyler."]
            ],
            video: [
              v("Pentago 1: İki yöne çevirme", "pentago-1-iki-yone-cevirme.mp4"),
              v("Pentago 2: Beş olunca", "pentago-2-bes-olunca.mp4"),
              v("Pentago 3: Berabere", "pentago-3-berabere.mp4"),
              v("Küre: Ajan taş", "kure-ajan-tas-dikey.mp4")
            ],
            etk: [["Pentago", 0], ["Pentago", 2], ["Pentago", 4], ["Küre", 0], ["Küre", 2], ["Küre", 3]],
            kuralKart: ["Pentago", "Küre"]
          },
          {
            ad: "Pentago: Beşi kur, tablayı çevir",
            oyunlar: ["Pentago"],
            amac: "Bilyeyi koyduktan sonra tablayı çevirmenin diziyi nasıl değiştirdiğini fark eder; tek hamlede kazanma ve rakibi durdurma bulmacalarını çözer.",
            dersler: [
              ["Kural tekrarı (10 dk)", "Kural kartı tahtada. Üç soru: Kim başlar? Tabla kaç derece döner? Çevirince ikimiz de beş olursak?"],
              ["Bulmacalar (30 dk)", "Pentago Bulmacaları Etkinlik 1 dağıtılır. Önce tek başına, sonra eşle karşılaştırma. Her soruda 'Önce bilyeyi koy, sonra hangi tablayı çevirdiğini ok ile göster.'"],
              ["Çözüm videosu (10 dk)", "Çözüm videosunu izleyin; öğrenciler kendi cevaplarını işaretler."],
              ["Eşli oyun ligi (30 dk)", "Her oyundan sonra eş değiştirilir (kazanan bir masa sağa). Kâğıda kazanılan oyun sayısı yazılır."],
              ["3. ders: Serbest oyun ve strateji sohbeti (40 dk)", "'Ortadaki çukurlar neden değerli?' 'Rakibin dörtlüsünü nasıl bozarım?' Öğrenci keşiflerini tahtaya yazın."]
            ],
            video: [v("Pentago bulmaca çözümü 1", "pentago-cozum-1.mp4")],
            pdf: [["Pentago Bulmacaları · Etkinlik 1", "pdf/kulup/Pentago-Bulmacalari-Etkinlik-1.pdf"]],
            etk: [["Pentago", 5], ["Pentago", 6], ["Pentago", 7]],
            kuralKart: ["Pentago"]
          },
          {
            ad: "Küre: Sıkıştır ve yakala",
            oyunlar: ["Küre"],
            amac: "Sıkıştırarak yakalama, çoklu yakalama, kendi isteğiyle araya girme ve dörtlü yasağı kurallarını örnek durumlarla uygular.",
            dersler: [
              ["Kural tekrarı (10 dk)", "Çoklu yakalama videosunu yeniden izleyin. 'Arada iki taş varsa hangisini alırım?' (İkisini de, hepsi alınmak zorunda.)"],
              ["Yakalama kâğıdı (25 dk)", "Küre: Yakalama etkinlik kâğıdı. Öğrenciler her durumda alınan taşları çarpı ile işaretler."],
              ["Eşli oyun (35 dk)", "Rakibin 4 taşını alan kazanır. Her oyun sonunda kazanan 'en iyi yakalamamı' eşine gösterir."],
              ["3. ders: Dörtlü yasağı avı (40 dk)", "Oyunlar sırasında öğretmen durdurur: 'Bu tahtada dörtlü olmak üzere olan var mı?' Doğru bulan masa puan alır."]
            ],
            video: [v("Küre: Çoklu yakalama", "kure-yeni-kural-coklu-yakalama.mp4")],
            kagitlar: ["kure-yakalama"],
            etk: [["Küre", 4], ["Küre", 6], ["Küre", 7]],
            kuralKart: ["Küre"]
          },
          {
            ad: "Equilibrio ile tanışma",
            oyunlar: ["Equilibrio"],
            amac: "Equilibrio parçalarını adlarıyla tanır, kutuyu sayarak kontrol eder ve kitapçıktaki bir şekli kartın aynısı olacak biçimde dizer.",
            dersler: [
              ["Parçalarla tanışma (15 dk)", "1. videoyu izleyin. Her eş kutusunu açar ve sayar: 4 küp, 4 kare prizma, 4 dik yamuk, 2 silindir, 2 üçgen prizma, 1 köprü, 1 yarım silindir (18 parça)."],
              ["Kitapçık (10 dk)", "2. videoyu izleyin. 'Şekil 12!' deyince önce kitapçık açılır, sonra dizilir."],
              ["Kolaydan zora (35 dk)", "Kitapçığın ilk renk seviyesinden sırayla 5 şekil. Eş kontrol eder: kartla aynı mı?"],
              ["3. ders: Hız turu (40 dk)", "Öğretmen şekil numarası söyler, ilk bitiren elini kaldırır. Puan tablosu tahtada."]
            ],
            video: [v("Equilibrio 1: Ekibiyle tanış", "equilibrio-1-tanis.mp4"), v("Equilibrio 2: Kitapçık", "equilibrio-2-kitapcik.mp4")],
            kuralKart: ["Equilibrio"]
          },
          {
            ad: "Equilibrio: Kartın aynısı, dengede",
            oyunlar: ["Equilibrio"],
            amac: "Açıklık bırakma, 'Bitirdim!' kuralı ve puanlama kurallarına uyarak süreli yarışır.",
            dersler: [
              ["Kurallar (15 dk)", "3, 4 ve 5. videoları izleyin. Açıklık kalmalı, birleştirme yok; yapı dengede durmalı; erken 'Bitirdim' uyarı getirir."],
              ["Hakemli eşleşme (35 dk)", "Üçlü gruplar: iki yarışmacı, bir hakem. Her turda 5 şekil, her şekil 1 puan. Roller her turda değişir."],
              ["3. ders: Mini lig (40 dk)", "Masalar arası eşleşme; turu alan 1 puan. Son 1 dakika uyarısını öğretmen yapar."]
            ],
            video: [v("Equilibrio 3: Açıklık", "equilibrio-3-aciklik.mp4"), v("Equilibrio 4: Bitirdim", "equilibrio-4-bitirdim.mp4"), v("Equilibrio 5: Tur, puan, süre", "equilibrio-5-tur-puan-sure.mp4")],
            kuralKart: ["Equilibrio"]
          },
          {
            ad: "Küre: Dörtlü yasağı ve rakip sıra",
            oyunlar: ["Küre"],
            amac: "Dörtlü yasağını, araya girme kuralını ve rakibin başlangıç sırasındaki tek taş kuralını örnek durumlarda uygular.",
            dersler: [
              ["Kural tekrarı (15 dk)", "TAZOF kural slaytlarında madde 8, 10 ve 12'yi okuyun. 'Aralarında boşluk varsa dörtlü sayılır mı?' (Evet.)"],
              ["Kural kâğıtları (35 dk)", "Dörtlü yasağı ve Araya gir, sıraya gir kâğıtları. Önce tek başına, sonra eşle karşılaştırma."],
              ["Eşli oyun (30 dk)", "Rakibin 4 taşını alan kazanır. Dörtlü yapan oyuncu hamlesini geri alır."],
              ["3. ders: Dört taşa giden yol (40 dk)", "Dört taşa giden yol kâğıdını çözün, en iyi hamleleri tahtada tartışın."]
            ],
            etk: [["Küre", 5], ["Küre", 8], ["Küre", 9]],
            kuralKart: ["Küre"]
          },
          {
            ad: "Pentago Seviye 2",
            oyunlar: ["Pentago"],
            amac: "Çevirme ile kazanma ve savunma bulmacalarını çözer; oyunda iki tehdit birden kurmayı dener.",
            dersler: [
              ["Isınma (10 dk)", "Geçen haftaki en zor bulmacayı tahtada birlikte çözün."],
              ["Seviye 2 bulmacaları (30 dk)", "Önce tek başına, sonra eşle. Doğru cevabı bulan öğrenci tahtada anlatır."],
              ["Çözüm videosu (10 dk)", "Video ile cevapları kontrol edin."],
              ["Oyun ligi (30 dk)", "Kazanan bir masa sağa geçer."],
              ["3. ders: Öğrenci bulmacası (40 dk)", "Her eş kendi Pentago bulmacasını çizer, başka bir eşe çözdürür."]
            ],
            video: [v("Pentago bulmaca çözümü 2", "pentago-cozum-2.mp4")],
            pdf: [["Pentago Bulmacaları · Seviye 2", "pdf/kulup/Pentago-Bulmacalari-Etkinlik-2-Seviye2.pdf"]],
            etk: [["Pentago", 8], ["Pentago", 9]],
            kuralKart: ["Pentago"]
          },
          {
            ad: "Küre mini turnuva",
            oyunlar: ["Küre"],
            amac: "Turnuva kurallarına (dokunulan taş oynanır, uyarı, el sıkışma) uyarak 3 turluk İsviçre sistemi turnuvada oynar.",
            dersler: [
              ["Turnuva kuralları (10 dk)", "Dokunduğun taşı oynarsın. Kural dışı hamle uyarı alır, 3. uyarıda tur kaybedilir. Kazanan 1, berabere 0,5 puan."],
              ["1. ve 2. tur (60 dk)", "Eşleşmeler tahtada. Sonuçları kazanan öğrenci öğretmene söyler."],
              ["3. ders: 3. tur ve ödül (40 dk)", "Sıralama okunur, herkes alkışlanır. En centilmen oyuncu da seçilir."]
            ],
            video: [v("Küre: Ajan taş", "kure-ajan-tas-dikey.mp4")],
            kuralKart: ["Küre"]
          },
          {
            ad: "Equilibrio hız ligi",
            oyunlar: ["Equilibrio"],
            amac: "Zorluk seviyesi artan şekilleri süreli olarak dizer; hatasını kendi fark eder.",
            dersler: [
              ["Isınma (10 dk)", "Bir şekli birlikte, sesli düşünerek dizin: 'Önce en alttaki parçayı buluyorum…'"],
              ["Seviye seviye (40 dk)", "Her öğrenci kendi hızında bir sonraki renk seviyesine geçer; eşi hakemlik yapar."],
              ["3. ders: Hız ligi (40 dk)", "Masalar arası 5 şekillik turlar. Puan tablosu tahtada."]
            ],
            video: [v("Equilibrio 3: Açıklık", "equilibrio-3-aciklik.mp4")],
            kuralKart: ["Equilibrio"]
          },
          {
            ad: "Pentago Seviye 3",
            oyunlar: ["Pentago"],
            amac: "İki hamle sonrasını düşünerek savunma ve çift tehdit bulmacalarını çözer.",
            dersler: [
              ["Seviye 3 bulmacaları (35 dk)", "Önce tek başına. Takılan öğrenci eşinden yalnızca bir ipucu isteyebilir."],
              ["Çözüm videosu (10 dk)", "Cevaplar videoyla kontrol edilir."],
              ["Oyun ligi (35 dk)", "Kazanan bir masa sağa."],
              ["3. ders: Ustaya karşı (40 dk)", "Öğretmen ya da en çok kazanan öğrenci aynı anda 3 masaya karşı oynar."]
            ],
            video: [v("Pentago bulmaca çözümü 3", "pentago-cozum-3.mp4")],
            pdf: [["Pentago Bulmacaları · Seviye 3", "pdf/kulup/Pentago-Bulmacalari-Etkinlik-3-Seviye3.pdf"]],
            etk: [["Pentago", 10], ["Pentago", 11]],
            kuralKart: ["Pentago"]
          },
          {
            ad: "İstasyon günü",
            oyunlar: ["Pentago", "Küre", "Equilibrio"],
            amac: "Üç oyunu istasyonlarda dönüşümlü oynar; hangi oyunda hangi düşünme becerisini kullandığını anlatır.",
            dersler: [
              ["İstasyonlar (80 dk)", "3 istasyon, her biri yaklaşık 26 dk: Pentago, Küre, Equilibrio. Zil çalınca gruplar saat yönünde döner."],
              ["3. ders: Oyun tasarla (40 dk)", "Eşler sevdikleri bir oyunun kuralından birini değiştirerek yeni bir oyun icat eder ve sınıfa anlatır."]
            ],
            kuralKart: ["Pentago", "Küre", "Equilibrio"]
          },
          {
            ad: "Dönem sonu kulüp turnuvası",
            oyunlar: ["Pentago", "Küre"],
            amac: "Dönem boyunca öğrendiği oyunlarda turnuva kurallarıyla yarışır; centilmenlik gösterir.",
            dersler: [
              ["Pentago turnuvası (40 dk)", "3 tur İsviçre sistemi. Siyah başlar."],
              ["Küre turnuvası (40 dk)", "3 tur İsviçre sistemi. Mor başlar."],
              ["3. ders: Ödül ve değerlendirme (40 dk)", "Sıralamalar, katılım belgeleri ve 'Bu dönem öğrendiğim en önemli şey' kartları."]
            ],
            kuralKart: ["Pentago", "Küre"]
          }
        ]
      },
      SAT: {
        ad: "Satranç",
        blok: "2. Blok",
        ogretmen: "Ali Bakla",
        saatler: [["11.00 – 12.20", "4. – 5. ders"], ["12.20 – 12.30", "Teneffüs"], ["12.30 – 13.10", "6. ders"]],
        haftalar: [
          {
            ad: "Satranç tahtası ve taşlar",
            amac: "Tahtayı doğru yerleştirir (sağ alt köşe açık renk), yatay, dikey ve çaprazı ayırt eder, kareleri koordinatla adlandırır, taşları başlangıç dizilişine koyar.",
            oyunsuz: true,
            hedef: "Satranç tahtasını, kareleri ve taşları tanıyacağız.",
            dersler: [
              ["Satranç nedir? (10 dk)", "Satrancın iki kişilik bir savaş oyunu olduğunu, amacın rakip şahı mat etmek olduğunu anlatın."],
              ["Tahta (15 dk)", "Serbest tahtayı açın. 64 kare, açık ve koyu; sağ alt köşe açık renk. Yatay (1-8), dikey (a-h) ve çapraz çizgileri tahtada gösterin."],
              ["Birlikte yapalım (40 dk)", "Sunumdaki 10 soruyu çözün. Her soruda bir öğrenci tahtaya gelip kareye dokunur, kenardaki Doğru mu? düğmesine basar. Yanlışsa sınıftan yardım ister."],
              ["Başlangıç dizilişi (15 dk)", "Serbest tahtada taşları birlikte inceleyin: kale, at, fil köşeden ortaya; 'vezir kendi rengini sever' (beyaz vezir d1, siyah vezir d8); piyonlar önde."],
              ["6. ders: Etkinlik sayfaları (40 dk)", "Slaytta yaptıklarınızın benzeri 10 etkinlik sayfasını sırayla çözerler: önce tek başına, sonra eşle karşılaştırma. Hızlı bitirene sıradaki sayfa verilir, kalan sayfalar haftaya tamamlanır."]
            ],
            etk: [["Satranç", 0], ["Satranç", 1], ["Satranç", 2], ["Satranç", 3], ["Satranç", 4], ["Satranç", 5], ["Satranç", 6], ["Satranç", 7], ["Satranç", 8], ["Satranç", 9]],
            video: [y("Satranç dersi 1: tahta ve taşlar (YouTube'da ara)", "FM Yasin satranç ders 1")]
          },
          {
            ad: "Kale ve fil",
            amac: "Kalenin düz (yatay-dikey), filin çapraz gittiğini; kendi taşının üzerinden geçemediğini ve rakip taşı aldığını gösterir.",
            dersler: [
              ["Kale (25 dk)", "Video, sonra tahtada kale ile 'gidebileceği kareler'. Önünde kendi taşı varsa duramaz, rakip taşı varsa alır."],
              ["Fil (25 dk)", "Fil hep aynı renk karede kalır. Açık kare fili, koyu kare fili."],
              ["Kale ve fil savaşı (30 dk)", "Her oyuncuya 1 kale + 4 piyon. Piyonunu sona çıkaran ya da rakibin bütün taşlarını alan kazanır."],
              ["6. ders: Alıştırma kâğıdı (40 dk)", "Gidebileceği kareleri X ile işaretle, say."]
            ],
            video: [y("FM Yasin Ders 2: Kalenin hareketi", "FM Yasin Ders 2 Kalenin Hareketi satranç")],
            oyun: "Kale ve fil savaşı"
          },
          {
            ad: "Vezir ve şah",
            amac: "Vezirin kale ve filin birleşimi gibi gittiğini, şahın her yöne bir kare gittiğini ve tehdit altındaki kareye giremeyeceğini açıklar.",
            dersler: [
              ["Vezir (25 dk)", "Vezir = kale + fil. En güçlü taş. 'Vezir 27 kareye gidebilir mi?' (Ortadayken evet.)"],
              ["Şah (25 dk)", "Şah her yöne bir kare. Rakibin saldırdığı kareye giremez; iki şah yan yana gelemez."],
              ["Şah avı (30 dk)", "Beyaz: şah + vezir, siyah: şah + 3 piyon. Siyah piyonunu sona çıkarmaya çalışır."],
              ["6. ders: Alıştırma kâğıdı (40 dk)", "Vezir ve şahın gidebileceği kareler."]
            ],
            video: [y("Vezir ve şahın hareketi (YouTube'da ara)", "FM Yasin satranç vezirin hareketi")],
            oyun: "Şah avı"
          },
          {
            ad: "At",
            amac: "Atın 'L' biçiminde gittiğini ve taşların üzerinden atlayabildiğini gösterir; bir kareye en az kaç hamlede gideceğini bulur.",
            dersler: [
              ["At (25 dk)", "Video. 'İki düz, bir yana'. At her hamlede kare rengini değiştirir."],
              ["At turu (25 dk)", "Atı a1'den yıldızlı karelere en kısa yoldan götür."],
              ["Atlar ve piyonlar (30 dk)", "Her oyuncuya 2 at + 8 piyon. Piyonunu sona çıkaran kazanır."],
              ["6. ders: Alıştırma kâğıdı (40 dk)", "Atın kareleri ve en kısa yollar."]
            ],
            video: [y("FM Yasin Ders 5: Atın hareketi", "FM Yasin Ders 5 Atın Hareketi satranç")],
            oyun: "Atlar ve piyonlar"
          },
          {
            ad: "Piyon, terfi ve geçerken alma",
            amac: "Piyonun ileri gidip çapraz aldığını, ilk hamlede iki kare gidebildiğini, son yatayda terfi ettiğini ve geçerken almayı uygular.",
            dersler: [
              ["Piyon (20 dk)", "İlk hamlede 1 ya da 2 kare. Düz gider, çapraz alır, geri dönmez."],
              ["Terfi (15 dk)", "Son yataya ulaşan piyon vezir, kale, fil ya da at olur."],
              ["Geçerken alma (15 dk)", "Rakip piyon iki kare gelip yanına durursa, hemen bir sonraki hamlede onu çapraz alabilirsin."],
              ["Piyon savaşı (30 dk)", "Yalnız piyonlar. Piyonunu sona ilk çıkaran kazanır."],
              ["6. ders: Alıştırma kâğıdı (40 dk)", "Piyon hamleleri, terfi, geçerken alma."]
            ],
            video: [y("Piyon, terfi ve geçerken alma (YouTube'da ara)", "FM Yasin satranç piyonun hareketi geçerken alma")],
            oyun: "Piyon savaşı"
          },
          {
            ad: "Şah çekme, mat ve pat",
            amac: "Şah, mat ve pat durumlarını ayırt eder; şahtan kurtulmanın üç yolunu (kaç, araya gir, al) söyler.",
            dersler: [
              ["Şah! (20 dk)", "Şah tehdit altında. Üç kurtuluş: kaç, araya taş koy, saldıran taşı al."],
              ["Mat (20 dk)", "Kurtuluş yoksa mat, oyun biter."],
              ["Pat (15 dk)", "Sıra sende, şahın tehdit altında değil ama hiç kurallı hamlen yok: berabere!"],
              ["Mini oyunlar (25 dk)", "Öğretmenin kurduğu konumlardan oynayın: 'Mat edebilecek misin, yoksa pat mı yapacaksın?'"],
              ["6. ders: Alıştırma kâğıdı (40 dk)", "Şah mı, mat mı, pat mı?"]
            ],
            video: [y("Şah, mat ve pat (YouTube'da ara)", "FM Yasin satranç şah mat pat")],
            oyun: "Mat mı pat mı?"
          },
          {
            ad: "Rok ve taş değerleri",
            amac: "Rokun koşullarını sayar; taş değerlerini (piyon 1, at 3, fil 3, kale 5, vezir 9) kullanarak değişim yapıp yapmamaya karar verir.",
            dersler: [
              ["Rok (25 dk)", "Şah iki kare kaleye doğru, kale şahın üzerinden atlar. Koşullar: şah ve kale daha önce oynamamış, araları boş, şah tehdit altında değil, geçeceği kare tehdit altında değil."],
              ["Taş değerleri (20 dk)", "Kart oyunu: 'Atımı verip kaleni alırsam kârlı mıyım?'"],
              ["İlk tam oyun (35 dk)", "Eşler ilk tam satranç oyunlarını oynar. Öğretmen gezerek rok yapmayı hatırlatır."],
              ["6. ders: Alıştırma kâğıdı (40 dk)", "Rok yapılabilir mi? Kim önde?"]
            ],
            video: [y("Rok nasıl yapılır? (YouTube'da ara)", "FM Yasin satranç rok")],
            oyun: "İlk tam oyun"
          },
          {
            ad: "Temel matlar: kale ve vezirle mat",
            amac: "Şah + kale ve şah + vezirle, rakip şahı kenara sıkıştırarak tek hamlede mat eder.",
            dersler: [
              ["Kenar matı (25 dk)", "Rakip şah kenarda, bizim şah karşısında, kale ya da vezir son hamleyi yapar."],
              ["Merdiven matı (20 dk)", "İki kale ile basamak basamak sıkıştırma."],
              ["Mat yarışı (35 dk)", "Öğretmenin kurduğu konumda en az hamlede mat eden kazanır."],
              ["6. ders: Alıştırma kâğıdı (40 dk)", "Tek hamlede mat."]
            ],
            video: [y("Kale ve vezirle mat (YouTube'da ara)", "FM Yasin satranç kale ile mat")],
            oyun: "Mat yarışı"
          },
          {
            ad: "Açılış tuzakları: tembel matı ve çoban matı",
            amac: "En kısa mat örneklerini tanır, f7/f2 karesinin zayıflığını açıklar ve açılışın üç altın kuralını uygular.",
            dersler: [
              ["Tembel matı (15 dk)", "Video. f ve g piyonlarını erken oynamak neden tehlikeli?"],
              ["Çoban matı (20 dk)", "Vezir ve fil f7'ye birlikte saldırır. Nasıl korunuruz?"],
              ["Açılış kuralları (15 dk)", "Merkez, gelişim, rok. Veziri erken çıkarma."],
              ["Tam oyun (30 dk)", "Açılış kurallarına göre oynayın; ilk 6 hamleyi kâğıda yazın."],
              ["6. ders: Alıştırma kâğıdı (40 dk)", "Açılış tuzakları."]
            ],
            video: [y("FM Yasin Ders 13: Tembel matı ve çoban matı", "FM Yasin Ders 13 Tembel Matı ve Çoban Matı"), y("FM Yasin Ders 22: Açılış kısmında vezir", "FM Yasin Ders 22 Açılış Kısmında Vezir")],
            oyun: "Tam oyun"
          },
          {
            ad: "Taktik: çatal",
            amac: "Bir taşla aynı anda iki taşa saldırmayı (çatal) bulur; özellikle at ve vezir çatallarını uygular.",
            dersler: [
              ["Çatal nedir? (20 dk)", "Video. Bir taş, iki hedef. Atın çatalı en sinsi olanıdır."],
              ["Çatal avı (25 dk)", "Tahtada konumlar: 'Çatal karesi neresi?'"],
              ["Tam oyun (35 dk)", "Oyunda bir çatal yapan ya da rakibin çatalını fark eden öğrenci yıldız alır."],
              ["6. ders: Alıştırma kâğıdı (40 dk)", "Çatal bulmacaları."]
            ],
            video: [y("FM Yasin Ders 18: Çatal taktiği", "FM Yasin Ders 18 Çatal Taktiği")],
            oyun: "Çatal avı"
          },
          {
            ad: "Taktik: açmaz",
            amac: "Açmazdaki taşı bulur, açmaz kuran taşları (kale, fil, vezir) söyler ve oyunda açmaz kurar.",
            dersler: [
              ["Açmaz nedir? (20 dk)", "Video. Arkasında şah olan taş kıpırdayamaz."],
              ["Açmaz bul (25 dk)", "Tahtada konumlar: hangi taş açmazda?"],
              ["Tam oyun (35 dk)", "Açmaz yakalayan yıldız alır."],
              ["6. ders: Alıştırma kâğıdı (40 dk)", "Açmaz bulmacaları."]
            ],
            video: [y("FM Yasin Ders 21: Açmaz taktiği", "FM Yasin Ders 21 Açmaz Taktigi")],
            oyun: "Açmaz bul"
          },
          {
            ad: "Son yatay matı ve dönem sonu turnuvası",
            amac: "Son yatay zayıflığını görür, kendi şahına kaçış karesi açar; turnuvada kurallara ve centilmenliğe uyar.",
            dersler: [
              ["Son yatay (20 dk)", "Video. Piyonlar şahın önünü kapatırsa kale ya da vezir son yatayda mat eder."],
              ["Alıştırma kâğıdı (20 dk)", "Son yatay matı bulmacaları."],
              ["Kulüp turnuvası (40 dk + 6. ders)", "İsviçre sistemi, dokunulan taş oynanır, kazanan 1, berabere 0,5 puan. Dönem sonu sıralaması ve belgeler."]
            ],
            video: [y("FM Yasin Ders 38: Son yatay zayıflığı", "FM Yasin Ders 38 Son Yatay Zayıflığı")],
            oyun: "Kulüp turnuvası"
          }
        ]
      }
    },
    kurallar: {
      "Pentago": [
        "6 × 6 tahta, dört tane 3 × 3 tabladan oluşur.",
        "Siyah başlar.",
        "Sırası gelen, boş bir çukura bir bilye koyar, sonra dört tabladan birini 90° çevirir: saat yönünde de olur, tersine de.",
        "Yatay, dikey ya da çapraz 5 bilyeyi yan yana dizen kazanır.",
        "Bilyeyi koyunca 5 olduysa oyun biter, tablayı çevirmeye gerek yoktur.",
        "Çevirme sonunda iki oyuncunun da 5'i varsa oyun berabere biter."
      ],
      "Küre": [
        "7 × 7 tahtada her oyuncunun 7 taşı vardır.",
        "Başlangıçta morun soluna, turuncunun sağına bir rakip taş gelir (ajan taş). Ajan taş da aynı kurallarla oynar.",
        "Oyuna mor başlar.",
        "Başlangıç sırasındaki taşlar yalnızca ileri ya da çapraz 1 kare gider. Sıradan çıkan taş bir daha başlangıç sırasına dönemez.",
        "Diğer taşlar ileri, geri ya da çapraz 1 kare gider. Yana (yatay) gidilmez.",
        "Bir oyuncunun taşları yatay, dikey ya da çapraz dörtlü olamaz (arada boşluk ya da rakip taş olsa bile). Dörtlü yapmak hatalı hamledir.",
        "Rakip taşları kendi iki taşının arasına yatay, dikey ya da çapraz sıkıştıran onları alır. Arada kalanların hepsi alınmak zorundadır.",
        "Kendi isteğinle iki rakip taşın arasına girersen rakip o taşı alamaz.",
        "Rakibin başlangıç sırasında aynı anda yalnızca bir taşın olabilir.",
        "Rakibin 4 taşını alan kazanır.",
        "Dokunduğun taşı oynamak zorundasın."
      ],
      "Equilibrio": [
        "Kutuda 18 parça: 4 küp, 4 kare prizma, 4 dik yamuk, 2 silindir, 2 üçgen prizma, 1 köprü, 1 yarım silindir.",
        "Hakem şeklin numarasını söyler; önce kitapçık açılır, sonra dizilir.",
        "Yapı kartın aynısı olmalı: karttaki açıklıklar korunur, parçalar birleştirilmez.",
        "Bir parça düşerse toplanır, devam edilir.",
        "İlk bitiren elini kaldırır ve 'Bitirdim!' der; yapı dengede durmalıdır. Erken 'Bitirdim' uyarı getirir.",
        "Her turda 5 şekil, her şekil 1 puan. Turu alan 1, diğeri 0 puan."
      ]
    },
    // TAZOF turnuva kuralları, revizyon 03.10.2026 (tazof.org.tr/turnuvalar/turnuva-kurallari): oyunla ilgili maddeler, metne sadık
    tazofKaynak: "TAZOF Turnuva Kuralları · Revizyon 03.10.2026",
    tazof: {
      "Pentago": [
        [3, "Oyuna her zaman siyah renkli oyuncu başlar."],
        [5, "Oyuncu oyun tablasındaki 4 boş tabladan istediği yere taşını yerleştirdikten sonra bu parçalardan herhangi birini istediği yönde 90 derece çevirmek zorundadır."],
        [6, "Taşın konulmasının ardından tablanın çevrilmesi ile hamle tamamlanmış olur. Taş konulduğu anda 5 ya da 6'lı dizilim sağlandığı takdirde tabla çevrilmez. Oyun derhal sona erer."],
        [7, "Taşlarını yatay, dikey veya çapraz doğrultuda sıralı bir biçimde 5 veya daha fazla olarak sıralayan ilk oyuncu oyun setini kazanır. Tüm alanlar dolduğu halde her iki taraf da 5 veya daha fazla taş sıralayamadıysa oyun seti berabere biter."],
        [8, "Bir oyuncu yaptığı hamle ile hem kendi taşlarını hem de rakibinin taşlarını 5 veya daha fazla olacak şekilde sıralıyorsa, oyun berabere biter."],
        [9, "Bir oyuncu yaptığı hamle ile sadece rakibinin taşlarını 5 veya daha fazla sıralarsa, rakip oyuncu oyun setini kazanır."],
        [10, "Oyuncu taşını tablaya koyduğu anda o hamleyi yapmış sayılır. Taşını geri alamaz."],
        [11, "Oyuncu, tablayı çevirmek için hareket ettirdikten sonra hamlesinden vazgeçemez ya da başka bir tablayı çeviremez."]
      ],
      "Küre": [
        [3, "Oyunda; morun soluna, turuncunun sağına bir rakip taş gelecek şekilde başlangıç dizilişi yapılır."],
        [4, "Oyuna her zaman mor renkli oyuncu başlar."],
        [5, "Başlangıç sırasında bulunan taşlar yalnızca ileriye ya da çapraza doğru bir birim hareket edebilir. (Rakip başlangıç sırasındaki taş geri hamle yapabilir.)"],
        [6, "Başlangıç sırasından ayrılan taşlar bir daha başlangıç sırasına geri dönemez."],
        [7, "Başlangıç sırasının haricindeki taşlar ileri, geri veya çapraza doğru bir birim hareket edebilir. Yatay yönde hareket yapılamaz."],
        [8, "Bir oyuncunun taşları, dikey, yatay ya da çapraz doğrultuda dörtlü olamaz. Taşların sıralı, aralıklı ya da taşların arasında rakip taşların olması bu durumu değiştirmez."],
        [9, "Rakibin taşını ya da taşlarını kendi taşlarının arasına sıkıştıran oyuncu rakip taşı alır ve oyun alanı dışına çıkartır. (Birden fazla taş sıkıştırılıp alınabilir.) Sıkıştırılan taş ya da taşların tamamı alınmak zorundadır."],
        [10, "Sırası gelen oyuncu, rakibine ait iki taşın arasına hamle yaptığında oyun sırası rakibine geçer, rakip oyuncu araya giren taşı alamaz."],
        [11, "Oynanan hamle ile hem mor hem de turuncu taşlar arada kalıyorsa, hamleyi yapan oyuncu arada kalan taşı alır."],
        [12, "Oyuncu, rakibin başlangıç sırasında aynı anda yalnızca bir taş bulundurabilir."],
        [13, "Rakibinin dört taşını oyundan çıkartan oyuncu oyunu kazanır."],
        [14, "Oyuncu, dokunduğu taşı oynamak zorundadır."],
        [16, "Oyunculardan herhangi birisi taşlarını yatay, dikey veya çapraz doğrultuda dörtlü yaparsa, rakibin hakeme bildirmesi halinde bir uyarı cezası alır ve oyuncu taşını geri alarak kurallı bir hamle yapar."],
        [18, "Oyuncu 3. uyarı cezasını alırsa o turu kaybetmiş sayılır."]
      ]
    }
  };
})();
